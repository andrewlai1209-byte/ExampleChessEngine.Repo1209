#!/usr/bin/env python3
"""
Neural Chess Engine - Advanced Self-Play Training Pipeline

This pipeline implements Lc0/AlphaZero-style training:
1. Self-play game generation (parallel)
2. Neural network training on game results
3. Model evaluation and iteration
4. Distributed cloud training support

Flow:
  Games Generation → Data Aggregation → Neural Training → Model Selection → Repeat
"""

import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from collections import deque
import numpy as np
import torch
from datetime import datetime
import logging

# Assuming chess_engine and neural_evaluator are in the same directory
try:
    from chess_engine import ChessBoard, ChessEngine, Personality
    from neural_evaluator import ChessNeuralEvaluator, TrainingConfig, BoardFeatureExtractor
except ImportError:
    print("⚠️ Make sure chess_engine.py and neural_evaluator.py are in the same directory")


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('training.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class PipelineConfig:
    """Training pipeline configuration"""
    # Self-play generation
    games_per_iteration: int = 100
    max_moves_per_game: int = 200
    search_depth: int = 4
    
    # Neural network training
    training_epochs: int = 10
    batch_size: int = 32
    learning_rate: float = 0.001
    
    # Model management
    num_iterations: int = 50
    checkpoint_interval: int = 5
    
    # Evaluation
    evaluation_games: int = 20
    rating_threshold: float = 50.0  # ELO rating threshold for model acceptance
    
    # Data management
    keep_last_n_games: int = 1000
    data_dir: str = "./training_data"
    model_dir: str = "./models"
    
    # Parallel processing
    num_workers: int = 4
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    
    def __post_init__(self):
        Path(self.data_dir).mkdir(exist_ok=True)
        Path(self.model_dir).mkdir(exist_ok=True)


class GameRecorder:
    """Records game data in a format suitable for training"""
    
    def __init__(self, game_dict: dict):
        self.game = game_dict
        self.positions = []  # Positions throughout the game
    
    def record_position(self, board, move_idx: int):
        """Record board state at each move"""
        # Extract features for this position
        features = BoardFeatureExtractor.extract_features(board)
        self.positions.append({
            'fen': board.get_fen() if hasattr(board, 'get_fen') else 'unknown',
            'move_idx': move_idx,
            'features': features.tolist() if isinstance(features, np.ndarray) else features,
        })
    
    def finalize(self, result: str):
        """Finalize game recording"""
        self.game['result'] = result
        self.game['positions'] = self.positions
        self.game['recorded_at'] = datetime.now().isoformat()
        return self.game


class SelfPlayGenerator:
    """Generates self-play games using the neural-enhanced chess engine"""
    
    def __init__(self, evaluator: Optional[ChessNeuralEvaluator] = None,
                 use_neural_eval: bool = False):
        self.evaluator = evaluator
        self.use_neural_eval = use_neural_eval and evaluator is not None
        self.games_played = 0
        self.game_results = {'white_wins': 0, 'black_wins': 0, 'draws': 0}
    
    def play_game(self, depth: int = 4, max_moves: int = 200,
                  white_personality: Optional[Personality] = None,
                  black_personality: Optional[Personality] = None) -> dict:
        """
        Play one complete self-play game.
        
        Returns:
            Game data dictionary
        """
        board = ChessBoard()
        
        white_engine = ChessEngine(
            personality=white_personality or Personality(),
            depth=depth
        )
        black_engine = ChessEngine(
            personality=black_personality or Personality(),
            depth=depth
        )
        
        moves = []
        recorder = GameRecorder({
            'white_personality': asdict(white_personality or Personality()),
            'black_personality': asdict(black_personality or Personality()),
            'depth': depth,
        })
        
        is_white_turn = True
        move_count = 0
        
        while move_count < max_moves and board.has_legal_moves(is_white_turn):
            # Record position before move
            recorder.record_position(board, move_count)
            
            # Choose engine
            engine = white_engine if is_white_turn else black_engine
            
            # Find best move
            best_move = engine.find_best_move(board, is_white_turn)
            
            if not best_move:
                break
            
            from_pos, to_pos = best_move
            board.make_move(from_pos, to_pos)
            moves.append((from_pos, to_pos))
            
            # Check terminal conditions
            if board.is_in_check(not is_white_turn) and not board.has_legal_moves(not is_white_turn):
                result = 'white_wins' if not is_white_turn else 'black_wins'
                break
            elif not board.has_legal_moves(not is_white_turn):
                result = 'stalemate'
                break
            else:
                result = None
            
            is_white_turn = not is_white_turn
            move_count += 1
        
        if result is None:
            result = 'draw'
        
        # Record final position
        recorder.record_position(board, move_count)
        game_data = recorder.finalize(result)
        game_data['moves'] = [(f"{f[0]}{f[1]}", f"{t[0]}{t[1]}") for f, t in moves]
        game_data['move_count'] = len(moves)
        game_data['fen_final'] = board.get_fen() if hasattr(board, 'get_fen') else 'unknown'
        
        self.games_played += 1
        self.game_results[result if result in self.game_results else 'draws'] += 1
        
        return game_data
    
    def generate_games(self, num_games: int, depth: int = 4,
                      max_moves: int = 200) -> List[dict]:
        """Generate multiple games with varying personalities"""
        games = []
        
        logger.info(f"🎮 Generating {num_games} games with depth={depth}")
        start_time = time.time()
        
        for i in range(num_games):
            # Vary personalities for diversity
            white_pers = Personality(
                aggression=40 + (i % 40),
                positional=30 + ((i // 10) % 50),
                style=30 + ((i // 20) % 50),
            )
            black_pers = Personality(
                aggression=60 - (i % 30),
                positional=50 + ((i // 15) % 30),
                style=60 - ((i // 25) % 30),
            )
            
            game = self.play_game(
                depth=depth,
                max_moves=max_moves,
                white_personality=white_pers,
                black_personality=black_pers
            )
            games.append(game)
            
            if (i + 1) % max(1, num_games // 10) == 0:
                elapsed = time.time() - start_time
                rate = (i + 1) / elapsed
                logger.info(f"  {i + 1}/{num_games} games ({rate:.1f} games/sec)")
        
        elapsed = time.time() - start_time
        logger.info(f"✅ Generated {num_games} games in {elapsed:.1f}s")
        logger.info(f"   Results: W={self.game_results['white_wins']} "
                   f"B={self.game_results['black_wins']} "
                   f"D={self.game_results['draws']}")
        
        return games


class ModelEvaluator:
    """Evaluates neural network models through tournament play"""
    
    def __init__(self, evaluator: ChessNeuralEvaluator):
        self.evaluator = evaluator
    
    def rate_model(self, num_games: int = 20, depth: int = 4) -> Dict[str, float]:
        """
        Rate model performance through self-play tournaments.
        
        Returns:
            Statistics dict with win rate, average game length, etc.
        """
        logger.info(f"🏆 Rating model with {num_games} games")
        
        generator = SelfPlayGenerator(evaluator=self.evaluator, use_neural_eval=True)
        games = generator.generate_games(num_games, depth=depth)
        
        # Analyze results
        results = {
            'white_wins': sum(1 for g in games if g['result'] == 'white_wins'),
            'black_wins': sum(1 for g in games if g['result'] == 'black_wins'),
            'draws': sum(1 for g in games if g['result'] == 'stalemate'),
        }
        
        avg_moves = np.mean([g['move_count'] for g in games])
        
        stats = {
            'num_games': num_games,
            'white_win_rate': results['white_wins'] / num_games,
            'black_win_rate': results['black_wins'] / num_games,
            'draw_rate': results['draws'] / num_games,
            'avg_game_length': avg_moves,
            'timestamp': datetime.now().isoformat(),
        }
        
        logger.info(f"  W: {results['white_wins']} B: {results['black_wins']} D: {results['draws']}")
        logger.info(f"  Avg moves: {avg_moves:.1f}")
        
        return stats


class TrainingPipeline:
    """Main training pipeline orchestration"""
    
    def __init__(self, config: PipelineConfig = None):
        self.config = config or PipelineConfig()
        self.current_iteration = 0
        
        # Initialize neural evaluator
        nn_config = TrainingConfig(
            batch_size=self.config.batch_size,
            learning_rate=self.config.learning_rate,
            epochs=self.config.training_epochs,
            device=self.config.device,
            checkpoint_dir=self.config.model_dir,
        )
        self.evaluator = ChessNeuralEvaluator(config=nn_config)
        
        # Game storage (FIFO for recent games)
        self.game_database = deque(maxlen=self.config.keep_last_n_games)
        
        # Training history
        self.history = {
            'iteration': [],
            'games_played': [],
            'model_rating': [],
            'best_model_iteration': 0,
            'best_model_rating': -float('inf'),
        }
        
        logger.info("=" * 70)
        logger.info("🧠 Neural Chess Engine - Self-Play Training Pipeline")
        logger.info("=" * 70)
        logger.info(f"Config: {asdict(self.config)}")
    
    def run_iteration(self) -> Dict:
        """Run one complete training iteration"""
        self.current_iteration += 1
        logger.info(f"\n{'=' * 70}")
        logger.info(f"ITERATION {self.current_iteration}/{self.config.num_iterations}")
        logger.info(f"{'=' * 70}")
        
        iteration_start = time.time()
        
        # 1. Generate self-play games
        logger.info("\n[Phase 1] Generating self-play games...")
        generator = SelfPlayGenerator(evaluator=self.evaluator)
        games = generator.generate_games(
            num_games=self.config.games_per_iteration,
            depth=self.config.search_depth,
            max_moves=self.config.max_moves_per_game
        )
        
        # Store games
        for game in games:
            self.game_database.append(game)
        
        # 2. Train neural network
        logger.info(f"\n[Phase 2] Training neural network on {len(self.game_database)} games...")
        self.evaluator.train_on_games(list(self.game_database), epochs=self.config.training_epochs)
        
        # 3. Evaluate model
        logger.info(f"\n[Phase 3] Evaluating model...")
        evaluator = ModelEvaluator(self.evaluator)
        rating_stats = evaluator.rate_model(num_games=self.config.evaluation_games)
        
        model_rating = rating_stats['white_win_rate']  # Simple rating metric
        
        # 4. Checkpoint management
        logger.info(f"\n[Phase 4] Saving checkpoints...")
        if self.current_iteration % self.config.checkpoint_interval == 0:
            self.evaluator.save_checkpoint(f"iteration_{self.current_iteration}")
        
        # Track best model
        if model_rating > self.history['best_model_rating']:
            self.history['best_model_rating'] = model_rating
            self.history['best_model_iteration'] = self.current_iteration
            self.evaluator.save_checkpoint("best_model")
            logger.info(f"🏆 New best model! Rating: {model_rating:.3f}")
        
        # 5. Log iteration results
        self.history['iteration'].append(self.current_iteration)
        self.history['games_played'].append(len(self.game_database))
        self.history['model_rating'].append(model_rating)
        
        iteration_time = time.time() - iteration_start
        
        logger.info(f"\n✅ Iteration {self.current_iteration} complete in {iteration_time:.1f}s")
        logger.info(f"   Model Rating: {model_rating:.3f}")
        logger.info(f"   Best Model: Iteration {self.history['best_model_iteration']} "
                   f"({self.history['best_model_rating']:.3f})")
        
        return {
            'iteration': self.current_iteration,
            'rating': model_rating,
            'games_in_database': len(self.game_database),
            'time_seconds': iteration_time,
            'rating_stats': rating_stats,
        }
    
    def run_training(self):
        """Run complete training pipeline"""
        logger.info("Starting training pipeline...")
        
        try:
            for iteration in range(self.config.num_iterations):
                result = self.run_iteration()
                self._save_history()
                
                # Stop if convergence (optional)
                if iteration > 10:
                    recent_ratings = self.history['model_rating'][-5:]
                    if len(recent_ratings) == 5:
                        rating_std = np.std(recent_ratings)
                        if rating_std < 0.01:
                            logger.info(f"Converged! Stopping training (rating std: {rating_std:.6f})")
                            break
        
        except KeyboardInterrupt:
            logger.info("Training interrupted by user")
        except Exception as e:
            logger.error(f"Training error: {e}", exc_info=True)
        
        finally:
            logger.info("\n" + "=" * 70)
            logger.info("TRAINING COMPLETE")
            logger.info("=" * 70)
            self._print_summary()
    
    def _save_history(self):
        """Save training history to file"""
        history_file = Path(self.config.data_dir) / "training_history.json"
        with open(history_file, 'w') as f:
            # Convert to JSON-serializable format
            history_dict = {k: v for k, v in self.history.items() if k != 'best_model_iteration'}
            history_dict['best_model_iteration'] = int(self.history['best_model_iteration'])
            json.dump(history_dict, f, indent=2)
    
    def _print_summary(self):
        """Print training summary"""
        if self.history['iteration']:
            logger.info(f"\nIterations completed: {len(self.history['iteration'])}")
            logger.info(f"Final model rating: {self.history['model_rating'][-1]:.3f}")
            logger.info(f"Best model (iteration {self.history['best_model_iteration']}): "
                       f"{self.history['best_model_rating']:.3f}")
            logger.info(f"Total games in database: {self.history['games_played'][-1]}")
            
            # Rating improvement
            if len(self.history['model_rating']) > 1:
                improvement = self.history['model_rating'][-1] - self.history['model_rating'][0]
                logger.info(f"Rating improvement: {improvement:+.3f}")


# Example usage
if __name__ == "__main__":
    # Configure pipeline
    config = PipelineConfig(
        games_per_iteration=10,  # Small for demo
        training_epochs=2,
        num_iterations=3,  # Short demo
        evaluation_games=5,
        search_depth=3,
        device="cpu",
    )
    
    # Run training
    pipeline = TrainingPipeline(config)
    pipeline.run_training()
    
    # Results will be in ./training_data/ and ./models/
