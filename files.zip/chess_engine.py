#!/usr/bin/env python3
"""
Neural Chess Engine - Open Source Classical Chess Engine
MIT License - Free to use, modify, and distribute

Features:
- Classical minimax search with alpha-beta pruning
- Configurable search depth
- Personality system (aggression, positional awareness, style)
- Self-play training capability
- UCI-compatible interface (basic)
"""

import copy
import time
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict
from enum import Enum
import json


class PieceType(Enum):
    PAWN = 'p'
    KNIGHT = 'n'
    BISHOP = 'b'
    ROOK = 'r'
    QUEEN = 'q'
    KING = 'k'


@dataclass
class Personality:
    """Engine personality parameters"""
    aggression: float = 50.0      # 0=defensive, 100=reckless
    positional: float = 50.0      # 0=material focus, 100=position focus
    style: float = 50.0           # 0=solid/safe, 100=attacking/creative

    def to_dict(self):
        return {
            'aggression': self.aggression,
            'positional': self.positional,
            'style': self.style
        }


class ChessBoard:
    """
    Represents a chess board state.
    Board layout: 8x8 array where index [0][0] is top-left (a8).
    """
    
    # Piece values for material evaluation
    PIECE_VALUES = {
        'p': 1,
        'n': 3,
        'b': 3,
        'r': 5,
        'q': 9,
        'k': 0,  # King has no material value in eval
    }

    def __init__(self, board=None):
        """Initialize board. If None, set up starting position."""
        if board is None:
            self.board = [
                ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
                ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
                [None] * 8,
                [None] * 8,
                [None] * 8,
                [None] * 8,
                ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
                ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
            ]
        else:
            self.board = copy.deepcopy(board)
        
        self.move_history = []
        self.fifty_move_count = 0

    def is_white(self, piece):
        """Check if piece belongs to white"""
        return piece and piece.isupper()

    def is_black(self, piece):
        """Check if piece belongs to black"""
        return piece and piece.islower()

    def in_bounds(self, row, col):
        """Check if position is within board"""
        return 0 <= row < 8 and 0 <= col < 8

    def get_piece(self, row, col):
        """Get piece at position"""
        if self.in_bounds(row, col):
            return self.board[row][col]
        return None

    def set_piece(self, row, col, piece):
        """Set piece at position"""
        if self.in_bounds(row, col):
            self.board[row][col] = piece

    def get_legal_moves(self, row, col) -> List[Tuple[int, int]]:
        """Get all legal moves for piece at position"""
        piece = self.get_piece(row, col)
        if not piece:
            return []

        moves = []
        piece_type = piece.lower()
        is_white = self.is_white(piece)

        if piece_type == 'p':
            moves.extend(self._get_pawn_moves(row, col, is_white))
        elif piece_type == 'n':
            moves.extend(self._get_knight_moves(row, col, is_white))
        elif piece_type == 'b':
            moves.extend(self._get_bishop_moves(row, col, is_white))
        elif piece_type == 'r':
            moves.extend(self._get_rook_moves(row, col, is_white))
        elif piece_type == 'q':
            moves.extend(self._get_queen_moves(row, col, is_white))
        elif piece_type == 'k':
            moves.extend(self._get_king_moves(row, col, is_white))

        return moves

    def _get_pawn_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal pawn moves"""
        moves = []
        direction = -1 if is_white else 1
        start_row = 6 if is_white else 1

        # Forward move
        forward_row = row + direction
        if self.in_bounds(forward_row, col) and not self.get_piece(forward_row, col):
            moves.append((forward_row, col))

            # Double move from start
            if row == start_row:
                forward2_row = row + 2 * direction
                if not self.get_piece(forward2_row, col):
                    moves.append((forward2_row, col))

        # Captures
        for dc in [-1, 1]:
            capture_row, capture_col = row + direction, col + dc
            if self.in_bounds(capture_row, capture_col):
                target = self.get_piece(capture_row, capture_col)
                if target and self.is_white(target) != is_white:
                    moves.append((capture_row, capture_col))

        return moves

    def _get_knight_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal knight moves"""
        moves = []
        directions = [(-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)]
        
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            if self.in_bounds(new_row, new_col):
                target = self.get_piece(new_row, new_col)
                if not target or self.is_white(target) != is_white:
                    moves.append((new_row, new_col))
        
        return moves

    def _get_sliding_moves(self, row, col, is_white, directions) -> List[Tuple[int, int]]:
        """Get moves for sliding pieces (bishop, rook, queen)"""
        moves = []
        
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            while self.in_bounds(new_row, new_col):
                target = self.get_piece(new_row, new_col)
                if not target:
                    moves.append((new_row, new_col))
                else:
                    if self.is_white(target) != is_white:
                        moves.append((new_row, new_col))
                    break
                new_row += dr
                new_col += dc
        
        return moves

    def _get_bishop_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal bishop moves"""
        directions = [(-1,-1),(-1,1),(1,-1),(1,1)]
        return self._get_sliding_moves(row, col, is_white, directions)

    def _get_rook_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal rook moves"""
        directions = [(-1,0),(1,0),(0,-1),(0,1)]
        return self._get_sliding_moves(row, col, is_white, directions)

    def _get_queen_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal queen moves"""
        directions = [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
        return self._get_sliding_moves(row, col, is_white, directions)

    def _get_king_moves(self, row, col, is_white) -> List[Tuple[int, int]]:
        """Get legal king moves (no castling for simplicity)"""
        moves = []
        directions = [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
        
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            if self.in_bounds(new_row, new_col):
                target = self.get_piece(new_row, new_col)
                if not target or self.is_white(target) != is_white:
                    moves.append((new_row, new_col))
        
        return moves

    def get_all_moves(self, is_white_turn: bool) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """Get all legal moves for one side as (from, to) tuples"""
        moves = []
        for r in range(8):
            for c in range(8):
                piece = self.get_piece(r, c)
                if piece and self.is_white(piece) == is_white_turn:
                    legal_moves = self.get_legal_moves(r, c)
                    for to_pos in legal_moves:
                        moves.append(((r, c), to_pos))
        return moves

    def make_move(self, from_pos: Tuple[int, int], to_pos: Tuple[int, int]):
        """Make a move and return whether it was a capture"""
        fr, fc = from_pos
        tr, tc = to_pos
        
        piece = self.get_piece(fr, fc)
        target = self.get_piece(tr, tc)
        
        self.set_piece(tr, tc, piece)
        self.set_piece(fr, fc, None)
        
        self.move_history.append((from_pos, to_pos, piece, target))
        self.fifty_move_count += 1
        
        if piece.lower() == 'p' or target:
            self.fifty_move_count = 0
        
        return target is not None

    def undo_move(self):
        """Undo last move"""
        if not self.move_history:
            return False
        
        from_pos, to_pos, piece, target = self.move_history.pop()
        fr, fc = from_pos
        tr, tc = to_pos
        
        self.set_piece(fr, fc, piece)
        self.set_piece(tr, tc, target)
        
        return True

    def find_king(self, is_white: bool) -> Optional[Tuple[int, int]]:
        """Find king position"""
        king = 'K' if is_white else 'k'
        for r in range(8):
            for c in range(8):
                if self.get_piece(r, c) == king:
                    return (r, c)
        return None

    def is_in_check(self, is_white: bool) -> bool:
        """Check if side is in check"""
        king_pos = self.find_king(is_white)
        if not king_pos:
            return False
        
        kr, kc = king_pos
        
        # Check if any enemy piece can attack the king
        for r in range(8):
            for c in range(8):
                piece = self.get_piece(r, c)
                if piece and self.is_white(piece) != is_white:
                    moves = self.get_legal_moves(r, c)
                    if (kr, kc) in moves:
                        return True
        
        return False

    def has_legal_moves(self, is_white: bool) -> bool:
        """Check if side has any legal moves"""
        return len(self.get_all_moves(is_white)) > 0

    def get_fen(self) -> str:
        """Get FEN representation (simplified)"""
        # Simplified FEN - just board state
        fen = ""
        for row in self.board:
            empty = 0
            for piece in row:
                if piece:
                    if empty:
                        fen += str(empty)
                        empty = 0
                    fen += piece
                else:
                    empty += 1
            if empty:
                fen += str(empty)
            fen += "/"
        return fen[:-1]  # Remove trailing slash


class ChessEngine:
    """
    Classical chess engine using minimax with alpha-beta pruning.
    Supports personality-based evaluation.
    """

    def __init__(self, personality: Optional[Personality] = None, depth: int = 4):
        self.personality = personality or Personality()
        self.depth = depth
        self.nodes_evaluated = 0
        self.transposition_table = {}

    def set_depth(self, depth: int):
        """Set search depth"""
        self.depth = max(1, min(depth, 10))

    def set_personality(self, personality: Personality):
        """Set engine personality"""
        self.personality = personality

    def evaluate(self, board: ChessBoard) -> float:
        """
        Evaluate board position from white's perspective.
        Higher = better for white, lower = better for black.
        Personality heavily influences evaluation.
        """
        score = 0.0

        # Material count
        for r in range(8):
            for c in range(8):
                piece = board.get_piece(r, c)
                if piece:
                    value = self.PIECE_VALUES.get(piece.lower(), 0)
                    if board.is_white(piece):
                        score += value
                    else:
                        score -= value

        # Positional bonuses
        for r in range(8):
            for c in range(8):
                piece = board.get_piece(r, c)
                if not piece:
                    continue

                is_white = board.is_white(piece)
                piece_type = piece.lower()

                # Central control (personality-dependent)
                distance_to_center = abs(r - 3.5) + abs(c - 3.5)
                central_bonus = (8 - distance_to_center) * (self.personality.positional / 100) * 0.2
                if is_white:
                    score += central_bonus
                else:
                    score -= central_bonus

                # Aggression bonus: attacking pieces
                if self.personality.aggression > 50:
                    num_attacks = len(board.get_legal_moves(r, c))
                    aggression_bonus = num_attacks * ((self.personality.aggression - 50) / 50) * 0.1
                    if is_white:
                        score += aggression_bonus
                    else:
                        score -= aggression_bonus

                # Style bonus: advanced pawns for attacking
                if piece_type == 'p' and self.personality.style > 50:
                    if is_white:
                        advance_bonus = (7 - r) * 0.2
                    else:
                        advance_bonus = r * 0.2
                    if is_white:
                        score += advance_bonus
                    else:
                        score -= advance_bonus

        # Checkmate/stalemate detection (handled elsewhere)
        return score

    def minimax(self, board: ChessBoard, current_depth: int, alpha: float, beta: float, 
                is_maximizing: bool) -> float:
        """
        Minimax search with alpha-beta pruning.
        is_maximizing=True means we're looking for white's best move.
        """
        self.nodes_evaluated += 1

        if current_depth == 0:
            return self.evaluate(board)

        moves = board.get_all_moves(is_maximizing)

        # Terminal position
        if not moves:
            if board.is_in_check(is_maximizing):
                # Checkmate
                return 10000 if is_maximizing else -10000
            else:
                # Stalemate
                return 0

        if is_maximizing:
            max_eval = float('-inf')
            for from_pos, to_pos in moves:
                board.make_move(from_pos, to_pos)
                eval_score = self.minimax(board, current_depth - 1, alpha, beta, False)
                board.undo_move()

                max_eval = max(max_eval, eval_score)
                alpha = max(alpha, eval_score)
                if beta <= alpha:
                    break  # Alpha-beta cutoff

            return max_eval
        else:
            min_eval = float('inf')
            for from_pos, to_pos in moves:
                board.make_move(from_pos, to_pos)
                eval_score = self.minimax(board, current_depth - 1, alpha, beta, True)
                board.undo_move()

                min_eval = min(min_eval, eval_score)
                beta = min(beta, eval_score)
                if beta <= alpha:
                    break

            return min_eval

    def find_best_move(self, board: ChessBoard, is_white_turn: bool) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """Find best move for the given side"""
        self.nodes_evaluated = 0
        moves = board.get_all_moves(is_white_turn)

        if not moves:
            return None

        best_move = moves[0]
        best_eval = float('inf') if not is_white_turn else float('-inf')

        for from_pos, to_pos in moves:
            board.make_move(from_pos, to_pos)
            eval_score = self.minimax(board, self.depth - 1, float('-inf'), float('inf'), not is_white_turn)
            board.undo_move()

            if is_white_turn:
                if eval_score > best_eval:
                    best_eval = eval_score
                    best_move = (from_pos, to_pos)
            else:
                if eval_score < best_eval:
                    best_eval = eval_score
                    best_move = (from_pos, to_pos)

        return best_move

    PIECE_VALUES = ChessBoard.PIECE_VALUES


class SelfPlayTrainer:
    """
    Trains engine through self-play games.
    Can be run on cloud infrastructure for distributed training.
    """

    def __init__(self, engine: ChessEngine, save_path: str = "chess_games.jsonl"):
        self.engine = engine
        self.save_path = save_path
        self.games = []

    def play_game(self, personality_white: Optional[Personality] = None,
                  personality_black: Optional[Personality] = None,
                  max_moves: int = 200) -> Dict:
        """Play one complete game"""
        board = ChessBoard()
        
        white_engine = ChessEngine(personality_white or Personality(), depth=self.engine.depth)
        black_engine = ChessEngine(personality_black or Personality(), depth=self.engine.depth)

        moves = []
        is_white_turn = True
        move_count = 0

        while move_count < max_moves and board.has_legal_moves(is_white_turn):
            engine = white_engine if is_white_turn else black_engine
            best_move = engine.find_best_move(board, is_white_turn)

            if not best_move:
                break

            from_pos, to_pos = best_move
            board.make_move(from_pos, to_pos)
            moves.append((from_pos, to_pos))

            # Check terminal conditions
            if board.is_in_check(not is_white_turn) and not board.has_legal_moves(not is_white_turn):
                # Checkmate
                result = 'white_wins' if not is_white_turn else 'black_wins'
                break
            elif not board.has_legal_moves(not is_white_turn):
                # Stalemate
                result = 'stalemate'
                break

            is_white_turn = not is_white_turn
            move_count += 1
        else:
            result = 'draw'  # Max moves reached

        game_data = {
            'moves': [(f"{pos[0]}{pos[1]}", f"{pos[0]}{pos[1]}") for pos, _ in moves],
            'result': result,
            'move_count': len(moves),
            'white_personality': (personality_white or Personality()).to_dict(),
            'black_personality': (personality_black or Personality()).to_dict(),
            'fen_final': board.get_fen(),
        }

        return game_data

    def train(self, num_games: int = 100):
        """Play multiple games and save results"""
        for i in range(num_games):
            # Vary personalities during training
            white_pers = Personality(
                aggression=50 + (i % 20),
                positional=50 + ((i // 20) % 20),
                style=50 + ((i // 40) % 20),
            )
            black_pers = Personality(
                aggression=50 + ((i + 10) % 20),
                positional=50 + ((i + 5) % 20),
                style=50 + ((i + 15) % 20),
            )

            game_data = self.play_game(white_pers, black_pers)
            self.games.append(game_data)

            if (i + 1) % 10 == 0:
                print(f"Completed {i + 1}/{num_games} games")
                self.save_games()

    def save_games(self):
        """Save games to JSONL file"""
        with open(self.save_path, 'w') as f:
            for game in self.games:
                f.write(json.dumps(game) + '\n')
        print(f"Saved {len(self.games)} games to {self.save_path}")


# Example usage
if __name__ == "__main__":
    print("♟️ Neural Chess Engine - Python Core")
    print("=" * 50)

    # Create engine with custom personality
    personality = Personality(aggression=75, positional=60, style=70)
    engine = ChessEngine(personality=personality, depth=4)

    # Play a sample game
    board = ChessBoard()
    is_white_turn = True
    move_count = 0

    print("\nStarting game (White = Human, Black = Engine)")
    print(f"Engine depth: {engine.depth}")
    print(f"Engine personality: Aggression={personality.aggression}, Positional={personality.positional}, Style={personality.style}\n")

    while board.has_legal_moves(is_white_turn) and move_count < 50:
        side = "White" if is_white_turn else "Black"
        
        if is_white_turn:
            # Human move (example)
            print(f"\n{side}'s turn. (Enter move as 'r0c0 r1c0' or 'quit')")
            user_input = input("> ").strip()
            if user_input.lower() == 'quit':
                break
            
            try:
                parts = user_input.split()
                from_pos = (int(parts[0][1]), int(parts[0][2]))
                to_pos = (int(parts[1][1]), int(parts[1][2]))
                board.make_move(from_pos, to_pos)
            except:
                print("Invalid move format")
                continue
        else:
            # Engine move
            print(f"\n{side}'s turn (thinking...)")
            start_time = time.time()
            best_move = engine.find_best_move(board, False)
            elapsed = time.time() - start_time
            
            if best_move:
                from_pos, to_pos = best_move
                board.make_move(from_pos, to_pos)
                print(f"Engine moved: {from_pos[0]}{from_pos[1]} -> {to_pos[0]}{to_pos[1]}")
                print(f"Nodes evaluated: {engine.nodes_evaluated}, Time: {elapsed:.2f}s")
            else:
                break

        is_white_turn = not is_white_turn
        move_count += 1

    print(f"\nGame ended after {move_count} moves")
    print("FEN:", board.get_fen())

    # Training example (uncomment to run)
    # print("\nStarting self-play training...")
    # trainer = SelfPlayTrainer(engine)
    # trainer.train(num_games=10)
