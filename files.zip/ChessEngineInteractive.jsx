import React, { useState, useEffect, useRef } from 'react';
import { AlertCircle, RotateCw, Settings } from 'lucide-react';

const ChessEngine = () => {
  // Board state
  const [board, setBoard] = useState(initializeBoard());
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [validMoves, setValidMoves] = useState([]);
  const [gameState, setGameState] = useState('playing'); // playing, checkmate, stalemate, check
  const [moveHistory, setMoveHistory] = useState([]);
  const [isEngineThinking, setIsEngineThinking] = useState(false);
  
  // Personality sliders
  const [personality, setPersonality] = useState({
    aggression: 50,        // 0=defensive, 100=reckless
    positional: 50,        // 0=material focus, 100=position focus
    style: 50,            // 0=solid/safe, 100=attacking/creative
  });
  
  const [depth, setDepth] = useState(4);
  const engineTimeoutRef = useRef(null);

  // Initialize standard chess board
  function initializeBoard() {
    const empty = Array(8).fill(null);
    return [
      ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
      ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
      [...empty],
      [...empty],
      [...empty],
      [...empty],
      ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
      ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
    ];
  }

  // Piece utility functions
  const isWhite = (piece) => piece && piece === piece.toUpperCase();
  const isBlack = (piece) => piece && piece === piece.toLowerCase();

  // Get all legal moves for a piece at position
  function getLegalMoves(row, col, boardState = board) {
    const piece = boardState[row][col];
    if (!piece) return [];

    const moves = [];
    const directions = {
      pawn: isWhite(piece) 
        ? [[-1, 0], [-2, 0], [-1, 1], [-1, -1]]
        : [[1, 0], [2, 0], [1, 1], [1, -1]],
      knight: [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],
      bishop: [[-1,-1],[-1,1],[1,-1],[1,1]],
      rook: [[-1,0],[1,0],[0,-1],[0,1]],
      queen: [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]],
      king: [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]],
    };

    const pieceLower = piece.toLowerCase();
    const dirs = directions[pieceLower] || [];

    if (pieceLower === 'pawn') {
      const direction = isWhite(piece) ? -1 : 1;
      const startRow = isWhite(piece) ? 6 : 1;
      
      // Forward move
      const forward1 = [row + direction, col];
      if (isInBounds(...forward1) && !boardState[forward1[0]][forward1[1]]) {
        moves.push(forward1);
      }
      
      // Double move from start
      if (row === startRow) {
        const forward2 = [row + 2 * direction, col];
        if (!boardState[forward2[0]][forward2[1]] && !boardState[forward1[0]][forward1[1]]) {
          moves.push(forward2);
        }
      }
      
      // Captures
      [-1, 1].forEach(dc => {
        const capturePos = [row + direction, col + dc];
        if (isInBounds(...capturePos)) {
          const target = boardState[capturePos[0]][capturePos[1]];
          if (target && isWhite(piece) !== isWhite(target)) {
            moves.push(capturePos);
          }
        }
      });
    } else if (pieceLower === 'knight' || pieceLower === 'king') {
      dirs.forEach(([dr, dc]) => {
        const newRow = row + dr, newCol = col + dc;
        if (isInBounds(newRow, newCol)) {
          const target = boardState[newRow][newCol];
          if (!target || isWhite(piece) !== isWhite(target)) {
            moves.push([newRow, newCol]);
          }
        }
      });
    } else {
      // Sliding pieces: bishop, rook, queen
      dirs.forEach(([dr, dc]) => {
        let newRow = row + dr, newCol = col + dc;
        while (isInBounds(newRow, newCol)) {
          const target = boardState[newRow][newCol];
          if (!target) {
            moves.push([newRow, newCol]);
          } else {
            if (isWhite(piece) !== isWhite(target)) {
              moves.push([newRow, newCol]);
            }
            break;
          }
          newRow += dr;
          newCol += dc;
        }
      });
    }

    return moves;
  }

  const isInBounds = (row, col) => row >= 0 && row < 8 && col >= 0 && col < 8;

  // Handle square click
  const handleSquareClick = (row, col) => {
    if (isEngineThinking) return;

    const piece = board[row][col];

    // Select piece
    if (piece && isWhite(piece)) {
      const moves = getLegalMoves(row, col);
      setSelectedSquare([row, col]);
      setValidMoves(moves);
    } 
    // Move piece
    else if (selectedSquare && validMoves.some(([r, c]) => r === row && c === col)) {
      makeMove(selectedSquare[0], selectedSquare[1], row, col, 'human');
      setSelectedSquare(null);
      setValidMoves([]);
    }
  };

  // Make move and update board
  const makeMove = (fromRow, fromCol, toRow, toCol, player = 'human') => {
    const newBoard = board.map(r => [...r]);
    const piece = newBoard[fromRow][fromCol];
    
    newBoard[toRow][toCol] = piece;
    newBoard[fromRow][fromCol] = null;

    setBoard(newBoard);
    setMoveHistory([...moveHistory, { from: [fromRow, fromCol], to: [toRow, toCol], piece }]);

    // Check game state
    const isWhiteKingInCheck = isKingInCheck(newBoard, true);
    const isBlackKingInCheck = isKingInCheck(newBoard, false);

    if (isBlackKingInCheck && hasNoLegalMoves(newBoard, false)) {
      setGameState('checkmate');
    } else if (isWhiteKingInCheck && hasNoLegalMoves(newBoard, true)) {
      setGameState('checkmate');
    } else if (!hasAnyLegalMoves(newBoard, false)) {
      setGameState('stalemate');
    } else if (isBlackKingInCheck || isWhiteKingInCheck) {
      setGameState('check');
    } else {
      setGameState('playing');
    }

    // Engine's turn
    if (player === 'human' && gameState !== 'checkmate') {
      setTimeout(() => engineMove(newBoard), 500);
    }
  };

  // Check if king is in check
  const isKingInCheck = (boardState, isWhiteKing) => {
    let kingPos = null;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if ((isWhiteKing && boardState[r][c] === 'K') ||
            (!isWhiteKing && boardState[r][c] === 'k')) {
          kingPos = [r, c];
        }
      }
    }
    
    if (!kingPos) return false;

    // Check if any opponent piece can attack king
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = boardState[r][c];
        if (piece && isWhite(piece) !== isWhiteKing) {
          const moves = getLegalMoves(r, c, boardState);
          if (moves.some(([kr, kc]) => kr === kingPos[0] && kc === kingPos[1])) {
            return true;
          }
        }
      }
    }
    return false;
  };

  // Check if has any legal moves
  const hasAnyLegalMoves = (boardState, isWhiteSide) => {
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = boardState[r][c];
        if (piece && isWhite(piece) === isWhiteSide) {
          if (getLegalMoves(r, c, boardState).length > 0) {
            return true;
          }
        }
      }
    }
    return false;
  };

  const hasNoLegalMoves = (boardState, isWhiteSide) => !hasAnyLegalMoves(boardState, isWhiteSide);

  // Engine evaluation with personality
  const evaluatePosition = (boardState, depth, personality) => {
    let score = 0;

    // Material count
    const pieceValues = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = boardState[r][c];
        if (piece) {
          const value = pieceValues[piece.toLowerCase()] || 0;
          score += isWhite(piece) ? value : -value;
        }
      }
    }

    // Positional bonuses based on personality
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = boardState[r][c];
        if (!piece) continue;

        // Central control (personality-dependent)
        const distToCenter = Math.abs(r - 3.5) + Math.abs(c - 3.5);
        const centralBonus = (8 - distToCenter) * (personality.positional / 100) * 0.2;
        score += isWhite(piece) ? centralBonus : -centralBonus;

        // Aggression: attacking pieces worth more
        if (personality.aggression > 50) {
          const numAttacks = getLegalMoves(r, c, boardState).length;
          const aggressionBonus = numAttacks * ((personality.aggression - 50) / 50) * 0.1;
          score += isWhite(piece) ? aggressionBonus : -aggressionBonus;
        }

        // Style: advanced pawns more valuable for attacking style
        if (piece.toLowerCase() === 'p' && personality.style > 50) {
          const advancedBonus = (isWhite(piece) ? (7 - r) : r) * 0.2;
          score += isWhite(piece) ? advancedBonus : -advancedBonus;
        }
      }
    }

    return score;
  };

  // Minimax with alpha-beta pruning
  const minimax = (boardState, currentDepth, alpha, beta, isMaximizing, personality) => {
    if (currentDepth === 0) {
      return evaluatePosition(boardState, currentDepth, personality);
    }

    const moves = getAllMoves(boardState, isMaximizing);
    if (moves.length === 0) {
      return evaluatePosition(boardState, currentDepth, personality);
    }

    if (isMaximizing) {
      let maxEval = -Infinity;
      for (let [from, to] of moves) {
        const newBoard = boardState.map(r => [...r]);
        newBoard[to[0]][to[1]] = newBoard[from[0]][from[1]];
        newBoard[from[0]][from[1]] = null;

        const eval_ = minimax(newBoard, currentDepth - 1, alpha, beta, false, personality);
        maxEval = Math.max(maxEval, eval_);
        alpha = Math.max(alpha, eval_);
        if (beta <= alpha) break;
      }
      return maxEval;
    } else {
      let minEval = Infinity;
      for (let [from, to] of moves) {
        const newBoard = boardState.map(r => [...r]);
        newBoard[to[0]][to[1]] = newBoard[from[0]][from[1]];
        newBoard[from[0]][from[1]] = null;

        const eval_ = minimax(newBoard, currentDepth - 1, alpha, beta, true, personality);
        minEval = Math.min(minEval, eval_);
        beta = Math.min(beta, eval_);
        if (beta <= alpha) break;
      }
      return minEval;
    }
  };

  // Get all legal moves for a side
  const getAllMoves = (boardState, isWhiteSide) => {
    const moves = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = boardState[r][c];
        if (piece && isWhite(piece) === isWhiteSide) {
          const pieceMoves = getLegalMoves(r, c, boardState);
          pieceMoves.forEach(to => moves.push([[r, c], to]));
        }
      }
    }
    return moves;
  };

  // Engine move
  const engineMove = (boardState) => {
    setIsEngineThinking(true);
    clearTimeout(engineTimeoutRef.current);

    engineTimeoutRef.current = setTimeout(() => {
      const moves = getAllMoves(boardState, false);
      if (moves.length === 0) {
        setIsEngineThinking(false);
        return;
      }

      let bestMove = moves[0];
      let bestEval = Infinity;

      moves.forEach(([from, to]) => {
        const newBoard = boardState.map(r => [...r]);
        newBoard[to[0]][to[1]] = newBoard[from[0]][from[1]];
        newBoard[from[0]][from[1]] = null;

        const eval_ = minimax(newBoard, depth - 1, -Infinity, Infinity, true, personality);
        
        if (eval_ < bestEval) {
          bestEval = eval_;
          bestMove = [from, to];
        }
      });

      makeMove(bestMove[0][0], bestMove[0][1], bestMove[1][0], bestMove[1][1], 'engine');
      setIsEngineThinking(false);
    }, 300);
  };

  // Reset game
  const resetGame = () => {
    setBoard(initializeBoard());
    setSelectedSquare(null);
    setValidMoves([]);
    setGameState('playing');
    setMoveHistory([]);
  };

  const squareColor = (row, col) => (row + col) % 2 === 0 ? '#f0d9b5' : '#b58863';
  const pieceSymbols = {
    p: '♟', P: '♙', r: '♜', R: '♖', n: '♞', N: '♘',
    b: '♝', B: '♗', q: '♛', Q: '♕', k: '♚', K: '♔'
  };

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)', padding: '2rem' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: '2rem', textAlign: 'center' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#fff', marginBottom: '0.5rem' }}>
            ♟️ Neural Chess Engine
          </h1>
          <p style={{ color: '#aaa', fontSize: '0.95rem' }}>Play against a personality-driven AI</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', alignItems: 'start' }}>
          {/* Board */}
          <div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(8, 1fr)',
              gap: '2px',
              background: '#333',
              padding: '8px',
              borderRadius: '8px',
              boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
            }}>
              {board.map((row, r) => row.map((piece, c) => (
                <div
                  key={`${r}-${c}`}
                  onClick={() => handleSquareClick(r, c)}
                  style={{
                    width: '50px',
                    height: '50px',
                    background: selectedSquare && selectedSquare[0] === r && selectedSquare[1] === c
                      ? '#baca44'
                      : validMoves.some(([vr, vc]) => vr === r && vc === c)
                      ? '#cdd26a'
                      : squareColor(r, c),
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '2rem',
                    cursor: 'pointer',
                    borderRadius: '4px',
                    transition: 'all 0.2s',
                    border: validMoves.some(([vr, vc]) => vr === r && vc === c) ? '2px solid #888' : 'none',
                  }}
                >
                  {piece && pieceSymbols[piece]}
                </div>
              )))}
            </div>
            <div style={{ marginTop: '1rem', textAlign: 'center', color: '#aaa', fontSize: '0.9rem' }}>
              {isEngineThinking ? '🤔 Engine thinking...' : gameState === 'checkmate' ? '♔ Checkmate!' : gameState === 'stalemate' ? '⚪ Stalemate' : gameState === 'check' ? '⚠️ Check!' : ''}
            </div>
          </div>

          {/* Controls */}
          <div style={{ background: 'rgba(255,255,255,0.05)', borderRadius: '12px', padding: '1.5rem', border: '1px solid rgba(255,255,255,0.1)' }}>
            <h2 style={{ color: '#fff', fontSize: '1.2rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Settings size={20} /> Engine Settings
            </h2>

            {/* Depth */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <label style={{ color: '#ddd', fontSize: '0.9rem', fontWeight: '500' }}>Search Depth</label>
                <span style={{ color: '#0f9', fontSize: '0.9rem', fontWeight: 'bold' }}>{depth}</span>
              </div>
              <input
                type="range"
                min="2"
                max="8"
                value={depth}
                onChange={(e) => setDepth(parseInt(e.target.value))}
                style={{ width: '100%', accentColor: '#0f9' }}
              />
              <p style={{ fontSize: '0.75rem', color: '#888', marginTop: '0.3rem' }}>Higher = stronger but slower</p>
            </div>

            {/* Personality Sliders */}
            <h3 style={{ color: '#fff', fontSize: '1rem', marginBottom: '1rem', marginTop: '2rem' }}>Playing Style</h3>

            {/* Aggression */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <label style={{ color: '#ddd', fontSize: '0.9rem', fontWeight: '500' }}>Aggression</label>
                <span style={{ color: '#0f9', fontSize: '0.9rem' }}>
                  {personality.aggression < 40 ? 'Defensive' : personality.aggression > 60 ? 'Reckless' : 'Balanced'}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={personality.aggression}
                onChange={(e) => setPersonality({ ...personality, aggression: parseInt(e.target.value) })}
                style={{ width: '100%', accentColor: '#f84' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: '#666', marginTop: '0.3rem' }}>
                <span>Defensive</span><span>Reckless</span>
              </div>
            </div>

            {/* Positional */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <label style={{ color: '#ddd', fontSize: '0.9rem', fontWeight: '500' }}>Position Awareness</label>
                <span style={{ color: '#0f9', fontSize: '0.9rem' }}>
                  {personality.positional < 40 ? 'Material' : personality.positional > 60 ? 'Strategic' : 'Balanced'}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={personality.positional}
                onChange={(e) => setPersonality({ ...personality, positional: parseInt(e.target.value) })}
                style={{ width: '100%', accentColor: '#4f9' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: '#666', marginTop: '0.3rem' }}>
                <span>Material Focus</span><span>Position Focus</span>
              </div>
            </div>

            {/* Style */}
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <label style={{ color: '#ddd', fontSize: '0.9rem', fontWeight: '500' }}>Playing Style</label>
                <span style={{ color: '#0f9', fontSize: '0.9rem' }}>
                  {personality.style < 40 ? 'Solid' : personality.style > 60 ? 'Attacking' : 'Adaptive'}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={personality.style}
                onChange={(e) => setPersonality({ ...personality, style: parseInt(e.target.value) })}
                style={{ width: '100%', accentColor: '#49f' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: '#666', marginTop: '0.3rem' }}>
                <span>Solid/Safe</span><span>Attacking/Creative</span>
              </div>
            </div>

            {/* Reset Button */}
            <button
              onClick={resetGame}
              style={{
                width: '100%',
                padding: '0.75rem',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: '#fff',
                border: 'none',
                borderRadius: '6px',
                fontSize: '1rem',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                transition: 'opacity 0.2s',
              }}
              onMouseEnter={(e) => e.target.style.opacity = '0.9'}
              onMouseLeave={(e) => e.target.style.opacity = '1'}
            >
              <RotateCw size={18} /> New Game
            </button>

            {/* Info */}
            <div style={{ marginTop: '1.5rem', padding: '1rem', background: 'rgba(255,255,255,0.05)', borderRadius: '6px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <AlertCircle size={16} style={{ color: '#0f9', flexShrink: 0 }} />
                <span style={{ fontSize: '0.85rem', color: '#aaa' }}>
                  You play as White. Adjust personality sliders and depth in real-time!
                </span>
              </div>
              <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.8rem' }}>
                <strong>Moves played:</strong> {moveHistory.length}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '2rem', textAlign: 'center', color: '#666', fontSize: '0.85rem', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '1.5rem' }}>
          <p>Open-source chess engine • MIT License • Built with React + Classical Search</p>
        </div>
      </div>
    </div>
  );
};

export default ChessEngine;
