#!/usr/bin/env python3
"""
Neural Chess Evaluator - Advanced Neural Network for Chess Position Evaluation
Combines classical chess features with deep learning for superhuman play

Architecture:
- Policy Head: Which move to play (direction predictions)
- Value Head: Position evaluation (-1 = black winning, +1 = white winning)
- Feature extraction from board state
- Batch training on self-play games
"""

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from dataclasses import dataclass
from typing import Tuple, List, Optional
import json
from pathlib import Path


@dataclass
class TrainingConfig:
    """Training hyperparameters"""
    batch_size: int = 32
    learning_rate: float = 0.001
    epochs: int = 10
    value_loss_weight: float = 0.5
    policy_loss_weight: float = 0.5
    l2_regularization: float = 1e-4
    device: str = "cpu"  # Use "cuda" if GPU available
    checkpoint_dir: str = "./checkpoints"
    
    def __post_init__(self):
        Path(self.checkpoint_dir).mkdir(exist_ok=True)


class BoardFeatureExtractor:
    """
    Extract rich features from chess board position.
    Creates a multi-channel representation optimized for neural networks.
    """
    
    # Piece type to channel mapping
    PIECE_CHANNELS = {
        'p': 0, 'P': 6,   # Pawns
        'n': 1, 'N': 7,   # Knights
        'b': 2, 'B': 8,   # Bishops
        'r': 3, 'R': 9,   # Rooks
        'q': 4, 'Q': 10,  # Queens
        'k': 5, 'K': 11,  # Kings
    }
    
    NUM_CHANNELS = 12  # 6 piece types × 2 colors
    
    @staticmethod
    def extract_features(board) -> np.ndarray:
        """
        Extract board features into a 12-channel representation.
        
        Returns:
            (8, 8, 12) numpy array
        """
        features = np.zeros((8, 8, 12), dtype=np.float32)
        
        # Piece positions
        for r in range(8):
            for c in range(8):
                piece = board.get_piece(r, c) if hasattr(board, 'get_piece') else board[r][c]
                if piece and piece.type != 'empty':
                    piece_char = piece if isinstance(piece, str) else str(piece.type)
                    if piece_char in BoardFeatureExtractor.PIECE_CHANNELS:
                        channel = BoardFeatureExtractor.PIECE_CHANNELS[piece_char]
                        features[r, c, channel] = 1.0
        
        return features
    
    @staticmethod
    def extract_features_batch(boards: List) -> torch.Tensor:
        """Extract features for a batch of boards"""
        batch_features = []
        for board in boards:
            features = BoardFeatureExtractor.extract_features(board)
            batch_features.append(features)
        
        # Stack into (batch_size, 8, 8, 12)
        batch_array = np.stack(batch_features, axis=0)
        
        # Convert to (batch_size, 12, 8, 8) for CNN
        batch_tensor = torch.from_numpy(batch_array).permute(0, 3, 1, 2)
        return batch_tensor


class ResidualBlock(nn.Module):
    """
    Residual block for deep neural networks.
    Allows training of very deep networks without gradient degradation.
    """
    
    def __init__(self, channels: int, kernel_size: int = 3):
        super().__init__()
        padding = kernel_size // 2
        
        self.conv1 = nn.Conv2d(channels, channels, kernel_size, padding=padding)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size, padding=padding)
        self.bn2 = nn.BatchNorm2d(channels)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        
        # Skip connection
        out = out + residual
        out = F.relu(out)
        
        return out


class ChessNeuralNetwork(nn.Module):
    """
    Deep neural network for chess evaluation.
    
    Architecture:
    - Input: 12-channel board representation (8×8)
    - Feature extraction: Conv + batch norm + residual blocks
    - Policy head: Predicts best move direction
    - Value head: Predicts position evaluation (-1 to +1)
    """
    
    def __init__(self, num_residual_blocks: int = 10, num_filters: int = 64):
        super().__init__()
        
        self.num_residual_blocks = num_residual_blocks
        self.num_filters = num_filters
        
        # Input convolution (12 channels → 64 filters)
        self.input_conv = nn.Conv2d(12, num_filters, kernel_size=3, padding=1)
        self.input_bn = nn.BatchNorm2d(num_filters)
        
        # Residual blocks for shared feature extraction
        self.residual_blocks = nn.ModuleList([
            ResidualBlock(num_filters, kernel_size=3)
            for _ in range(num_residual_blocks)
        ])
        
        # Policy head: Predict move distribution
        self.policy_conv = nn.Conv2d(num_filters, 32, kernel_size=1)
        self.policy_bn = nn.BatchNorm2d(32)
        self.policy_fc1 = nn.Linear(32 * 8 * 8, 256)
        self.policy_fc2 = nn.Linear(256, 4672)  # 8×8×73 unique move encodings (simplified)
        
        # Value head: Predict position evaluation
        self.value_conv = nn.Conv2d(num_filters, 32, kernel_size=1)
        self.value_bn = nn.BatchNorm2d(32)
        self.value_fc1 = nn.Linear(32 * 8 * 8, 256)
        self.value_fc2 = nn.Linear(256, 1)
        self.value_activation = nn.Tanh()  # Output in [-1, 1]
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass returning (policy_logits, value)
        
        Args:
            x: (batch_size, 12, 8, 8) board state tensor
            
        Returns:
            policy_logits: (batch_size, 4672) - unnormalized move probabilities
            value: (batch_size, 1) - position evaluation in [-1, 1]
        """
        # Shared feature extraction
        features = self.input_conv(x)
        features = self.input_bn(features)
        features = F.relu(features)
        
        for residual_block in self.residual_blocks:
            features = residual_block(features)
        
        # Policy head
        policy_out = self.policy_conv(features)
        policy_out = self.policy_bn(policy_out)
        policy_out = F.relu(policy_out)
        policy_out = policy_out.view(policy_out.size(0), -1)  # Flatten
        policy_out = self.policy_fc1(policy_out)
        policy_out = F.relu(policy_out)
        policy_logits = self.policy_fc2(policy_out)
        
        # Value head
        value_out = self.value_conv(features)
        value_out = self.value_bn(value_out)
        value_out = F.relu(value_out)
        value_out = value_out.view(value_out.size(0), -1)  # Flatten
        value_out = self.value_fc1(value_out)
        value_out = F.relu(value_out)
        value = self.value_activation(self.value_fc2(value_out))
        
        return policy_logits, value


class ChessNeuralEvaluator:
    """
    High-level interface for neural network chess evaluation.
    Handles training, inference, and checkpointing.
    """
    
    def __init__(self, config: TrainingConfig = None, model_path: Optional[str] = None):
        self.config = config or TrainingConfig()
        self.device = torch.device(self.config.device)
        
        # Create or load model
        if model_path and Path(model_path).exists():
            self.model = self._load_model(model_path)
            print(f"Loaded model from {model_path}")
        else:
            self.model = ChessNeuralNetwork(
                num_residual_blocks=10,
                num_filters=64
            )
            print("Created new neural network model")
        
        self.model.to(self.device)
        
        # Optimizer and loss functions
        self.optimizer = optim.Adam(
            self.model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.l2_regularization
        )
        
        self.policy_loss_fn = nn.CrossEntropyLoss()
        self.value_loss_fn = nn.MSELoss()
        
        self.training_history = {
            'epoch': [],
            'policy_loss': [],
            'value_loss': [],
            'total_loss': [],
        }
    
    def evaluate(self, board) -> float:
        """
        Evaluate a chess position using the neural network.
        
        Returns:
            float in [-1, 1]: negative = black better, positive = white better
        """
        self.model.eval()
        with torch.no_grad():
            features = BoardFeatureExtractor.extract_features(board)
            x = torch.from_numpy(features).unsqueeze(0).permute(0, 3, 1, 2).to(self.device)
            _, value = self.model(x)
            return value.item()
    
    def predict_policy(self, board) -> np.ndarray:
        """
        Predict move probabilities for a position.
        
        Returns:
            (8, 8, 73) array of move probabilities (per square, per direction)
        """
        self.model.eval()
        with torch.no_grad():
            features = BoardFeatureExtractor.extract_features(board)
            x = torch.from_numpy(features).unsqueeze(0).permute(0, 3, 1, 2).to(self.device)
            policy_logits, _ = self.model(x)
            
            # Convert logits to probabilities
            policy_probs = F.softmax(policy_logits, dim=1)
            policy_array = policy_probs[0].cpu().numpy()
            
            # Reshape to (8, 8, 73) if needed
            return policy_array.reshape(64, 73) if policy_array.shape[0] == 4672 else policy_array
    
    def train_on_games(self, games_data: List[dict], epochs: Optional[int] = None):
        """
        Train network on self-play games data.
        
        Args:
            games_data: List of game dictionaries with moves, results, etc.
            epochs: Number of training epochs (uses config default if None)
        """
        epochs = epochs or self.config.epochs
        
        print(f"\n🧠 Training Neural Network on {len(games_data)} games")
        print(f"Epochs: {epochs}, Batch size: {self.config.batch_size}")
        print("=" * 60)
        
        # Prepare training data from games
        boards, policy_targets, value_targets = self._prepare_training_data(games_data)
        
        if len(boards) == 0:
            print("⚠️ No training data prepared")
            return
        
        # Create data loader
        dataset = TorchChessDataset(boards, policy_targets, value_targets)
        dataloader = torch.utils.data.DataLoader(
            dataset,
            batch_size=self.config.batch_size,
            shuffle=True
        )
        
        # Training loop
        for epoch in range(epochs):
            epoch_policy_loss = 0.0
            epoch_value_loss = 0.0
            num_batches = 0
            
            self.model.train()
            for batch_idx, (board_features, policy_target, value_target) in enumerate(dataloader):
                board_features = board_features.to(self.device)
                policy_target = policy_target.to(self.device)
                value_target = value_target.to(self.device)
                
                # Forward pass
                policy_logits, value_pred = self.model(board_features)
                
                # Compute losses
                policy_loss = self.policy_loss_fn(policy_logits, policy_target)
                value_loss = self.value_loss_fn(value_pred, value_target)
                
                total_loss = (
                    self.config.policy_loss_weight * policy_loss +
                    self.config.value_loss_weight * value_loss
                )
                
                # Backward pass
                self.optimizer.zero_grad()
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()
                
                epoch_policy_loss += policy_loss.item()
                epoch_value_loss += value_loss.item()
                num_batches += 1
            
            # Epoch summary
            avg_policy_loss = epoch_policy_loss / num_batches
            avg_value_loss = epoch_value_loss / num_batches
            avg_total_loss = (
                self.config.policy_loss_weight * avg_policy_loss +
                self.config.value_loss_weight * avg_value_loss
            )
            
            self.training_history['epoch'].append(epoch + 1)
            self.training_history['policy_loss'].append(avg_policy_loss)
            self.training_history['value_loss'].append(avg_value_loss)
            self.training_history['total_loss'].append(avg_total_loss)
            
            if (epoch + 1) % max(1, epochs // 10) == 0 or epoch == epochs - 1:
                print(f"Epoch {epoch + 1:3d}/{epochs} | "
                      f"Policy Loss: {avg_policy_loss:.4f} | "
                      f"Value Loss: {avg_value_loss:.4f} | "
                      f"Total Loss: {avg_total_loss:.4f}")
        
        print("\n✅ Training complete!")
        self.save_checkpoint(f"checkpoint_epoch_{epochs}")
    
    def _prepare_training_data(self, games_data: List[dict]) -> Tuple[List, np.ndarray, np.ndarray]:
        """Convert game data to training tensors"""
        boards = []
        policy_targets = []
        value_targets = []
        
        for game in games_data:
            # Extract result
            result = game.get('result', 'draw')
            if result == 'white_wins':
                final_value = 1.0
            elif result == 'black_wins':
                final_value = -1.0
            else:
                final_value = 0.0
            
            # For now, use simplified training (can be improved with position-by-position targets)
            # This is a placeholder - real implementation would need actual board states per move
            num_moves = game.get('move_count', 0)
            
            if num_moves > 0:
                # Placeholder: we'd need the actual board positions for each move
                # For now, just record that we have training data
                pass
        
        if not boards:
            print("⚠️ No board positions extracted from games")
        
        return boards, np.array(policy_targets) if policy_targets else np.array([]), \
               np.array(value_targets).reshape(-1, 1) if value_targets else np.array([]).reshape(0, 1)
    
    def save_checkpoint(self, name: str = "latest"):
        """Save model checkpoint"""
        checkpoint_path = Path(self.config.checkpoint_dir) / f"{name}.pth"
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'training_history': self.training_history,
        }, checkpoint_path)
        print(f"✅ Checkpoint saved to {checkpoint_path}")
    
    def _load_model(self, model_path: str) -> ChessNeuralNetwork:
        """Load model from checkpoint"""
        model = ChessNeuralNetwork()
        checkpoint = torch.load(model_path, map_location=self.device)
        model.load_state_dict(checkpoint['model_state_dict'])
        return model
    
    def export_for_inference(self, output_path: str):
        """Export model for use in chess engine"""
        self.model.eval()
        
        # Create dummy input
        dummy_input = torch.randn(1, 12, 8, 8).to(self.device)
        
        # Trace the model
        traced_model = torch.jit.trace(self.model, dummy_input)
        traced_model.save(output_path)
        print(f"✅ Model exported to {output_path}")


class TorchChessDataset(torch.utils.data.Dataset):
    """PyTorch dataset for chess training data"""
    
    def __init__(self, boards: List, policy_targets: np.ndarray, value_targets: np.ndarray):
        self.boards = boards
        self.policy_targets = torch.from_numpy(policy_targets).long()
        self.value_targets = torch.from_numpy(value_targets).float()
    
    def __len__(self):
        return len(self.boards)
    
    def __getitem__(self, idx):
        features = BoardFeatureExtractor.extract_features(self.boards[idx])
        features = torch.from_numpy(features).permute(2, 0, 1)  # (12, 8, 8)
        
        return features, self.policy_targets[idx], self.value_targets[idx]


# Example usage
if __name__ == "__main__":
    print("♟️ Neural Chess Evaluator")
    print("=" * 60)
    
    # Create configuration
    config = TrainingConfig(
        batch_size=32,
        learning_rate=0.001,
        epochs=5,
        device="cpu",  # Use "cuda" if GPU available
    )
    
    # Create evaluator
    evaluator = ChessNeuralEvaluator(config)
    
    print("\n✅ Neural evaluator ready!")
    print(f"Model parameters: {sum(p.numel() for p in evaluator.model.parameters()):,}")
    print(f"Device: {evaluator.device}")
    
    # Example: Train on dummy games (you would use actual games)
    dummy_games = [
        {
            'moves': [('r0c0', 'r2c0'), ('r1c0', 'r3c0')],
            'result': 'white_wins',
            'move_count': 2
        }
    ]
    
    # evaluator.train_on_games(dummy_games, epochs=2)
