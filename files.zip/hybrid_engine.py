#!/usr/bin/env python3
"""
Hybrid Chess Engine - Combines Classical Search + Neural Network Evaluation

Strategy:
- Use minimax + alpha-beta pruning at shallow depths (classical)
- Use neural network for position evaluation (modern)
- Result: Speed of classical + accuracy of neural networks

Similar to: Stockfish + NNUE, Lc0 (with small searches)
"""

import time
import numpy as np
from typing import Tuple, Optional, Dict
from dataclasses import dataclass
import logging

try:
    from chess_engine import ChessBoard, Personality
    from neural_evaluator import ChessNeuralEvaluator, BoardFeatureExtractor
except ImportError:
    print("⚠️ Make sure chess_engine.py and neural_evaluator.py are available")


logger = logging.getLogger(__name__)


@dataclass
class HybridEngineConfig:
    """Configuration for hybrid engine"""
    search_depth: int = 4
    use_neural_eval: bool = True
    neural_weight: float = 0.7  # 0 = pure classical, 1 = pure neural
    personality: Personality = None
    use_move_ordering: bool = True
    use_transposition_table: bool = True


class TranspositionTable:
    """
    Cache for previously evaluated positions.
    Drastically speeds up search by avoiding re-evaluation.
    """
    
    def __init__(self, max_entries: int = 100000):
        self.table = {}
        self.max_entries = max_entries
        self.hits = 0
        self.misses = 0
    
    def store(self, board_fen: str, depth: int, score: float, flag: str):
        """
        Store position evaluation.
        flag: 'exact', 'lower', 'upper' (alpha-beta bounds)
        """
        if len(self.table) >= self.max_entries:
            # Simple replacement: clear half the table
            keys_to_remove = list(self.table.keys())[:len(self.table) // 2]
            for key in keys_to_remove:
                del self.table[key]
        
        self.table[board_fen] = {
            'depth': depth,
            'score': score,
            'flag': flag,
        }
    
    def lookup(self, board_fen: str, depth: int) -> Optional[float]:
        """Look up position (returns None if not found or insufficient depth)"""
        if board_fen not in self.table:
            self.misses += 1
            return None
        
        entry = self.table[board_fen]
        if entry['depth'] >= depth:
            self.hits += 1
            return entry['score']
        
        self.misses += 1
        return None
    
    def clear(self):
        """Clear the table"""
        self.table.clear()
        self.hits = 0
        self.misses = 0
    
    def stats(self) -> Dict:
        """Return cache statistics"""
        total = self.hits + self.misses
        hit_rate = self.hits / total if total > 0 else 0
        return {
            'entries': len(self.table),
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': hit_rate,
        }


class HybridChessEngine:
    """
    Hybrid engine combining classical search with neural evaluation.
    
    Search: Classical minimax + alpha-beta
    Eval: Blends neural network with classical evaluation
    """
    
    # Piece values for classical evaluation
    PIECE_VALUES = {
        'p': 1,
        'n': 3,
        'b': 3,
        'r': 5,
        'q': 9,
        'k': 0,
    }
    
    def __init__(self, neural_evaluator: Optional[ChessNeuralEvaluator] = None,
                 config: HybridEngineConfig = None):
        self.config = config or HybridEngineConfig()
        self.neural_evaluator = neural_evaluator
        self.transposition_table = TranspositionTable()
        
        self.nodes_evaluated = 0
        self.tt_lookups = 0
        
        logger.info("⚙️ Hybrid Engine initialized")
        logger.info(f"   Depth: {self.config.search_depth}")
        logger.info(f"   Neural eval: {self.config.use_neural_eval}")
        logger.info(f"   Neural weight: {self.config.neural_weight}")
    
    def evaluate(self, board: ChessBoard) -> float:
        """
        Evaluate position using hybrid scoring.
        
        Classical score (material + position) + Neural score
        Weight them by config.neural_weight
        """
        classical_score = self._evaluate_classical(board)
        
        if not self.config.use_neural_eval or self.neural_evaluator is None:
            return classical_score
        
        # Get neural evaluation
        try:
            neural_score = self.neural_evaluator.evaluate(board)
            # Normalize neural score (-1 to 1) to same scale as classical
            neural_score = neural_score * 10.0  # Scale to approximate classical range
        except Exception as e:
            logger.warning(f"Neural evaluation failed: {e}, using classical only")
            return classical_score
        
        # Blend scores
        alpha = self.config.neural_weight
        blended_score = (1 - alpha) * classical_score + alpha * neural_score
        
        return blended_score
    
    def _evaluate_classical(self, board: ChessBoard) -> float:
        """
        Classical evaluation function.
        Material count + positional bonuses + personality factors.
        """
        score = 0.0
        
        # Material count
        for r in range(8):
            for c in range(8):
                piece = board.get_piece(r, c)
                if piece and piece.type != 'empty':
                    value = self.PIECE_VALUES.get(str(piece.type).lower(), 0)
                    if piece.is_white:
                        score += value
                    else:
                        score -= value
        
        # Positional bonuses
        personality = self.config.personality or Personality()
        
        for r in range(8):
            for c in range(8):
                piece = board.get_piece(r, c)
                if not piece or piece.type == 'empty':
                    continue
                
                is_white = piece.is_white
                
                # Central control
                dist_to_center = abs(r - 3.5) + abs(c - 3.5)
                central_bonus = (8 - dist_to_center) * (personality.positional / 100) * 0.2
                
                # Pawn advancement bonus (for attacking style)
                if str(piece.type).lower() == 'p' and personality.style > 50:
                    advance_bonus = (7 - r if is_white else r) * 0.1
                else:
                    advance_bonus = 0
                
                piece_bonus = central_bonus + advance_bonus
                
                if is_white:
                    score += piece_bonus
                else:
                    score -= piece_bonus
        
        return score
    
    def find_best_move(self, board: ChessBoard, is_white_turn: bool,
                      time_limit: Optional[float] = None) -> Optional[Tuple]:
        """
        Find best move using iterative deepening.
        
        Args:
            board: Current board state
            is_white_turn: True if white to move
            time_limit: Maximum time in seconds (if None, uses fixed depth)
        
        Returns:
            (from_pos, to_pos) or None if no legal moves
        """
        self.nodes_evaluated = 0
        self.tt_lookups = 0
        
        moves = board.get_all_moves(is_white_turn)
        if not moves:
            return None
        
        start_time = time.time()
        best_move = moves[0]
        best_eval = -float('inf') if is_white_turn else float('inf')
        
        # Iterative deepening: try increasing depths
        for current_depth in range(1, self.config.search_depth + 1):
            if time_limit and (time.time() - start_time) > time_limit * 0.8:
                break  # Stop if running out of time
            
            # Score all moves at this depth
            move_scores = []
            for from_pos, to_pos in moves:
                board.make_move(from_pos, to_pos)
                score = self._minimax(
                    board,
                    current_depth - 1,
                    -float('inf'),
                    float('inf'),
                    not is_white_turn
                )
                board.undo_move()
                move_scores.append((score, from_pos, to_pos))
            
            # Select best move at this depth
            if is_white_turn:
                best_move_at_depth = max(move_scores, key=lambda x: x[0])
                if best_move_at_depth[0] > best_eval:
                    best_eval = best_move_at_depth[0]
                    best_move = (best_move_at_depth[1], best_move_at_depth[2])
            else:
                best_move_at_depth = min(move_scores, key=lambda x: x[0])
                if best_move_at_depth[0] < best_eval:
                    best_eval = best_move_at_depth[0]
                    best_move = (best_move_at_depth[1], best_move_at_depth[2])
        
        elapsed = time.time() - start_time
        logger.debug(f"Search: {self.nodes_evaluated} nodes, {elapsed:.2f}s, "
                    f"TT: {self.transposition_table.stats()['hit_rate']:.1%}")
        
        return best_move
    
    def _minimax(self, board: ChessBoard, depth: int, alpha: float, beta: float,
                is_maximizing: bool) -> float:
        """
        Minimax with alpha-beta pruning and transposition table.
        """
        self.nodes_evaluated += 1
        
        # Check transposition table
        board_fen = board.get_fen() if hasattr(board, 'get_fen') else str(board)
        tt_score = self.transposition_table.lookup(board_fen, depth)
        if tt_score is not None:
            self.tt_lookups += 1
            return tt_score
        
        # Terminal conditions
        if depth == 0:
            eval_score = self.evaluate(board)
            self.transposition_table.store(board_fen, depth, eval_score, 'exact')
            return eval_score
        
        moves = board.get_all_moves(is_maximizing)
        
        if not moves:
            if board.is_in_check(is_maximizing):
                score = 10000 if not is_maximizing else -10000  # Checkmate
            else:
                score = 0  # Stalemate
            self.transposition_table.store(board_fen, depth, score, 'exact')
            return score
        
        # Move ordering: try better moves first (heuristic)
        if self.config.use_move_ordering:
            moves = self._order_moves(board, moves)
        
        # Minimax search
        if is_maximizing:
            max_eval = -float('inf')
            for from_pos, to_pos in moves:
                board.make_move(from_pos, to_pos)
                eval_score = self._minimax(board, depth - 1, alpha, beta, False)
                board.undo_move()
                
                max_eval = max(max_eval, eval_score)
                alpha = max(alpha, eval_score)
                
                if beta <= alpha:
                    break  # Prune
            
            self.transposition_table.store(board_fen, depth, max_eval, 'exact')
            return max_eval
        else:
            min_eval = float('inf')
            for from_pos, to_pos in moves:
                board.make_move(from_pos, to_pos)
                eval_score = self._minimax(board, depth - 1, alpha, beta, True)
                board.undo_move()
                
                min_eval = min(min_eval, eval_score)
                beta = min(beta, eval_score)
                
                if beta <= alpha:
                    break  # Prune
            
            self.transposition_table.store(board_fen, depth, min_eval, 'exact')
            return min_eval
    
    def _order_moves(self, board: ChessBoard, moves: list) -> list:
        """
        Order moves heuristically to improve alpha-beta pruning.
        Prioritize: captures > checks > advancing > retreating
        """
        def move_score(move):
            from_pos, to_pos = move
            target = board.get_piece(to_pos[0], to_pos[1])
            
            # Captures first (high value)
            if target and target.type != 'empty':
                return 1000 + self.PIECE_VALUES.get(str(target.type).lower(), 0)
            
            # Advancing pawns
            piece = board.get_piece(from_pos[0], from_pos[1])
            if piece and str(piece.type).lower() == 'p':
                return 100
            
            # Default
            return 0
        
        return sorted(moves, key=move_score, reverse=True)
    
    def reset_stats(self):
        """Reset search statistics"""
        self.nodes_evaluated = 0
        self.tt_lookups = 0
        self.transposition_table.clear()


# Example usage
if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    
    print("♟️ Hybrid Chess Engine")
    print("=" * 60)
    
    # Create engine with classical evaluation
    config = HybridEngineConfig(
        search_depth=4,
        use_neural_eval=False,  # Disabled for this example
        personality=Personality(aggression=60, positional=70, style=50)
    )
    
    engine = HybridChessEngine(config=config)
    
    # Test game
    board = ChessBoard()
    is_white = True
    move_count = 0
    
    print("Starting test game (10 moves)...")
    while move_count < 10 and board.has_legal_moves(is_white):
        print(f"\n{['Black', 'White'][is_white]}'s turn...")
        
        start = time.time()
        best_move = engine.find_best_move(board, is_white)
        elapsed = time.time() - start
        
        if best_move:
            from_pos, to_pos = best_move
            board.make_move(from_pos, to_pos)
            print(f"Move: {from_pos} -> {to_pos}")
            print(f"Nodes: {engine.nodes_evaluated}, Time: {elapsed:.2f}s")
        else:
            break
        
        is_white = not is_white
        move_count += 1
    
    print(f"\nTest complete! {move_count} moves played")
