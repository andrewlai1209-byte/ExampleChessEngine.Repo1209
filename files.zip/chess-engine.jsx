import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';

/**
 * Vibe Chess Engine - Play-style configurable chess AI
 * MIT License - Open source chess engine with personality
 * 
 * Features:
 * - Alpha-beta minimax with iterative deepening
 * - Personality system: Aggression, Positional, Endgame sliders
 * - Drag-to-move UI, real-time depth control
 * - Runs entirely in browser
 */

// ============================================================================
// CHESS LOGIC LAYER
// ============================================================================

class ChessBoard {
  constructor() {
    // FEN-like board representation (8x8, 0-63 flat array)
    this.board = new Array(64).fill(null);
    this.initializeBoard();
    this.moveHistory = [];
    this.whiteToMove = true;
    this.castleRights = { white: { kingside: true, queenside: true }, black: { kingside: true, queenside: true } };
    this.enPassantSquare = null;
    this.halfMoveClock = 0;
    this.fullMoveNumber = 1;
  }

  initializeBoard() {
    const startPos = [
      'r', 'n', 'b', 'q', 'k', 'b', 'n', 'r',
      'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p',
      null, null, null, null, null, null, null, null,
      null, null, null, null, null, null, null, null,
      null, null, null, null, null, null, null, null,
      null, null, null, null, null, null, null, null,
      'P', 'P', 'P', 'P', 'P', 'P', 'P', 'P',
      'R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'
    ];
    this.board = [...startPos];
  }

  isWhitePiece(piece) { return piece && piece === piece.toUpperCase(); }
  isBlackPiece(piece) { return piece && piece === piece.toLowerCase(); }

  getSquare(row, col) { return row * 8 + col; }
  getRowCol(square) { return [Math.floor(square / 8), square % 8]; }

  getLegalMoves(square) {
    const moves = [];
    const piece = this.board[square];
    if (!piece) return moves;

    const isWhite = this.isWhitePiece(piece);
    const [row, col] = this.getRowCol(square);
    const pieceLower = piece.toLowerCase();

    const tryMove = (r, c) => {
      if (r < 0 || r > 7 || c < 0 || c > 7) return;
      const targetSquare = this.getSquare(r, c);
      const target = this.board[targetSquare];
      if (target && ((isWhite && this.isWhitePiece(target)) || (!isWhite && this.isBlackPiece(target)))) return;
      moves.push(targetSquare);
    };

    if (pieceLower === 'p') {
      const dir = isWhite ? -1 : 1;
      const startRow = isWhite ? 6 : 1;
      const forwardSquare = this.getSquare(row + dir, col);
      if (forwardSquare >= 0 && forwardSquare < 64 && !this.board[forwardSquare]) {
        moves.push(forwardSquare);
        if (row === startRow) {
          const doubleSquare = this.getSquare(row + 2 * dir, col);
          if (!this.board[doubleSquare]) moves.push(doubleSquare);
        }
      }
      // Captures
      for (const dcol of [-1, 1]) {
        const captureSquare = this.getSquare(row + dir, col + dcol);
        if (captureSquare >= 0 && captureSquare < 64) {
          const target = this.board[captureSquare];
          if (target && ((isWhite && this.isBlackPiece(target)) || (!isWhite && this.isWhitePiece(target)))) {
            moves.push(captureSquare);
          }
        }
      }
    } else if (pieceLower === 'n') {
      const deltas = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
      deltas.forEach(([dr, dc]) => tryMove(row + dr, col + dc));
    } else if (pieceLower === 'b' || pieceLower === 'r' || pieceLower === 'q') {
      const dirs = [];
      if (pieceLower === 'r' || pieceLower === 'q') dirs.push([-1, 0], [1, 0], [0, -1], [0, 1]);
      if (pieceLower === 'b' || pieceLower === 'q') dirs.push([-1, -1], [-1, 1], [1, -1], [1, 1]);
      for (const [dr, dc] of dirs) {
        for (let i = 1; i < 8; i++) {
          const nr = row + i * dr, nc = col + i * dc;
          if (nr < 0 || nr > 7 || nc < 0 || nc > 7) break;
          const target = this.board[this.getSquare(nr, nc)];
          if (!target) moves.push(this.getSquare(nr, nc));
          else {
            if ((isWhite && this.isBlackPiece(target)) || (!isWhite && this.isWhitePiece(target))) {
              moves.push(this.getSquare(nr, nc));
            }
            break;
          }
        }
      }
    } else if (pieceLower === 'k') {
      for (const dr of [-1, 0, 1]) {
        for (const dc of [-1, 0, 1]) {
          if (dr === 0 && dc === 0) continue;
          tryMove(row + dr, col + dc);
        }
      }
    }

    return moves.filter(target => this.isLegalAfterMove(square, target));
  }

  isLegalAfterMove(from, to) {
    const temp = this.board[to];
    this.board[to] = this.board[from];
    this.board[from] = null;
    const legal = !this.isInCheck(this.whiteToMove);
    this.board[from] = this.board[to];
    this.board[to] = temp;
    return legal;
  }

  isInCheck(isWhite) {
    let kingSquare = -1;
    const king = isWhite ? 'K' : 'k';
    for (let i = 0; i < 64; i++) if (this.board[i] === king) kingSquare = i;
    if (kingSquare === -1) return false;

    for (let i = 0; i < 64; i++) {
      const piece = this.board[i];
      if (!piece) continue;
      if ((isWhite && this.isWhitePiece(piece)) || (!isWhite && this.isBlackPiece(piece))) continue;
      
      const moves = this.getPseudoLegalMoves(i);
      if (moves.includes(kingSquare)) return true;
    }
    return false;
  }

  getPseudoLegalMoves(square) {
    const moves = [];
    const piece = this.board[square];
    if (!piece) return moves;

    const isWhite = this.isWhitePiece(piece);
    const [row, col] = this.getRowCol(square);
    const pieceLower = piece.toLowerCase();

    const tryMove = (r, c) => {
      if (r < 0 || r > 7 || c < 0 || c > 7) return;
      const targetSquare = this.getSquare(r, c);
      const target = this.board[targetSquare];
      if (target && ((isWhite && this.isWhitePiece(target)) || (!isWhite && this.isBlackPiece(target)))) return;
      moves.push(targetSquare);
    };

    if (pieceLower === 'p') {
      const dir = isWhite ? -1 : 1;
      tryMove(row + dir, col);
      tryMove(row + dir, col - 1);
      tryMove(row + dir, col + 1);
    } else if (pieceLower === 'n') {
      const deltas = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
      deltas.forEach(([dr, dc]) => tryMove(row + dr, col + dc));
    } else if (pieceLower === 'b' || pieceLower === 'r' || pieceLower === 'q') {
      const dirs = [];
      if (pieceLower === 'r' || pieceLower === 'q') dirs.push([-1, 0], [1, 0], [0, -1], [0, 1]);
      if (pieceLower === 'b' || pieceLower === 'q') dirs.push([-1, -1], [-1, 1], [1, -1], [1, 1]);
      for (const [dr, dc] of dirs) {
        for (let i = 1; i < 8; i++) {
          const nr = row + i * dr, nc = col + i * dc;
          if (nr < 0 || nr > 7 || nc < 0 || nc > 7) break;
          const target = this.board[this.getSquare(nr, nc)];
          if (!target) moves.push(this.getSquare(nr, nc));
          else {
            if ((isWhite && this.isBlackPiece(target)) || (!isWhite && this.isWhitePiece(target))) {
              moves.push(this.getSquare(nr, nc));
            }
            break;
          }
        }
      }
    } else if (pieceLower === 'k') {
      for (const dr of [-1, 0, 1]) {
        for (const dc of [-1, 0, 1]) {
          if (dr === 0 && dc === 0) continue;
          tryMove(row + dr, col + dc);
        }
      }
    }

    return moves;
  }

  makeMove(from, to) {
    this.board[to] = this.board[from];
    this.board[from] = null;
    this.moveHistory.push({ from, to });
    this.whiteToMove = !this.whiteToMove;
    this.halfMoveClock++;
    if (!this.whiteToMove) this.fullMoveNumber++;
  }

  clone() {
    const cloned = new ChessBoard();
    cloned.board = [...this.board];
    cloned.whiteToMove = this.whiteToMove;
    cloned.moveHistory = [...this.moveHistory];
    cloned.castleRights = JSON.parse(JSON.stringify(this.castleRights));
    cloned.enPassantSquare = this.enPassantSquare;
    cloned.halfMoveClock = this.halfMoveClock;
    cloned.fullMoveNumber = this.fullMoveNumber;
    return cloned;
  }

  getAllLegalMoves() {
    const moves = [];
    for (let i = 0; i < 64; i++) {
      const piece = this.board[i];
      if (!piece) continue;
      if ((this.whiteToMove && !this.isWhitePiece(piece)) || (!this.whiteToMove && !this.isBlackPiece(piece))) continue;
      
      const squareMoves = this.getLegalMoves(i);
      for (const to of squareMoves) {
        moves.push({ from: i, to });
      }
    }
    return moves;
  }

  isGameOver() {
    return this.getAllLegalMoves().length === 0;
  }
}

// ============================================================================
// EVALUATION FUNCTION WITH PERSONALITY
// ============================================================================

class Evaluator {
  constructor(personality = {}) {
    // Personality parameters: 0-100 scale
    this.aggression = personality.aggression ?? 50;      // Risk-taking, attack bonus
    this.positional = personality.positional ?? 50;      // Strategy vs tactics
    this.endgame = personality.endgame ?? 50;            // Endgame technique
    
    // Piece values
    this.pieceValues = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 0 };
  }

  evaluate(board) {
    let whiteScore = 0, blackScore = 0;

    // Material count
    for (let i = 0; i < 64; i++) {
      const piece = board.board[i];
      if (!piece) continue;
      const value = this.pieceValues[piece.toUpperCase()];
      if (board.isWhitePiece(piece)) whiteScore += value;
      else blackScore += value;
    }

    // Positional bonuses (enhanced by positional preference)
    const positionalFactor = this.positional / 50;
    
    // Piece-square tables (simplified)
    for (let i = 0; i < 64; i++) {
      const piece = board.board[i];
      if (!piece) continue;
      const [row, col] = board.getRowCol(i);
      let bonus = 0;

      const pieceLower = piece.toLowerCase();
      
      // Pawn advancement bonus
      if (pieceLower === 'p') {
        bonus = board.isWhitePiece(piece) ? (6 - row) * 5 : (row - 1) * 5;
      }
      // Knight centralization
      else if (pieceLower === 'n') {
        const dist = Math.abs(row - 3.5) + Math.abs(col - 3.5);
        bonus = (8 - dist) * 3;
      }
      // Bishop long diagonals
      else if (pieceLower === 'b') {
        bonus = Math.abs(row - col) > 2 ? 5 : 0;
      }
      // Rook on open files
      else if (pieceLower === 'r') {
        let openFile = true;
        for (let r = 0; r < 8; r++) {
          if (board.board[board.getSquare(r, col)]?.toLowerCase() === 'p') {
            openFile = false;
            break;
          }
        }
        bonus = openFile ? 15 : 0;
      }
      // King safety (avoid center in midgame, seek center in endgame)
      else if (pieceLower === 'k') {
        const endgameFactor = this.endgame / 50;
        const centerDist = Math.abs(row - 3.5) + Math.abs(col - 3.5);
        bonus = endgameFactor > 1.2 ? (8 - centerDist) * 3 : centerDist * 2;
      }

      bonus *= positionalFactor;
      
      if (board.isWhitePiece(piece)) whiteScore += bonus;
      else blackScore += bonus;
    }

    // Attack aggression bonus
    const aggressionFactor = this.aggression / 50;
    const whiteLegalMoves = board.getAllLegalMoves().length;
    const blackBoard = board.clone();
    blackBoard.whiteToMove = false;
    const blackLegalMoves = blackBoard.getAllLegalMoves().length;

    whiteScore += (whiteLegalMoves - blackLegalMoves) * aggressionFactor * 2;

    // King safety (reduced by aggression, increased by caution)
    if (board.isInCheck(true)) whiteScore -= 50 * (1 - aggressionFactor * 0.5);
    if (board.isInCheck(false)) blackScore -= 50 * (1 - aggressionFactor * 0.5);

    return whiteScore - blackScore;
  }
}

// ============================================================================
// CHESS ENGINE
// ============================================================================

class ChessEngine {
  constructor(personality = {}) {
    this.evaluator = new Evaluator(personality);
    this.transpositionTable = new Map();
    this.nodesEvaluated = 0;
    this.depth = 0;
  }

  negamax(board, depth, alpha, beta, isMaximizing) {
    this.nodesEvaluated++;

    if (depth === 0) {
      const score = this.evaluator.evaluate(board);
      return isMaximizing ? score : -score;
    }

    const moves = board.getAllLegalMoves();
    if (moves.length === 0) {
      return board.isInCheck(board.whiteToMove) ? -100000 : 0;
    }

    // Order moves (captures first)
    moves.sort((a, b) => {
      const scoreA = board.board[a.to] ? 1 : 0;
      const scoreB = board.board[b.to] ? 1 : 0;
      return scoreB - scoreA;
    });

    let maxEval = -Infinity;
    for (const move of moves) {
      const boardCopy = board.clone();
      boardCopy.makeMove(move.from, move.to);
      const eval_ = -this.negamax(boardCopy, depth - 1, -beta, -alpha, !isMaximizing);
      maxEval = Math.max(maxEval, eval_);
      alpha = Math.max(alpha, eval_);
      if (alpha >= beta) break;
    }

    return maxEval;
  }

  getBestMove(board, targetDepth) {
    this.depth = targetDepth;
    this.nodesEvaluated = 0;

    const moves = board.getAllLegalMoves();
    if (moves.length === 0) return null;

    let bestMove = moves[0];
    let bestScore = -Infinity;

    for (const move of moves) {
      const boardCopy = board.clone();
      boardCopy.makeMove(move.from, move.to);
      const score = -this.negamax(boardCopy, targetDepth - 1, -Infinity, Infinity, false);

      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }

    return bestMove;
  }
}

// ============================================================================
// REACT COMPONENT - UI & GAME LOGIC
// ============================================================================

export default function ChessEngineUI() {
  const [board, setBoard] = useState(() => new ChessBoard());
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [validMoves, setValidMoves] = useState([]);
  const [gameMessage, setGameMessage] = useState('');
  const [depth, setDepth] = useState(4);
  const [engineThinking, setEngineThinking] = useState(false);
  const [moveCount, setMoveCount] = useState(0);
  
  // Personality sliders
  const [aggression, setAggression] = useState(50);
  const [positional, setPositional] = useState(50);
  const [endgame, setEndgame] = useState(50);

  const engineRef = useRef(null);

  // Create/update engine when personality changes
  useEffect(() => {
    engineRef.current = new ChessEngine({ aggression, positional, endgame });
  }, [aggression, positional, endgame]);

  const handleSquareClick = useCallback((square) => {
    if (engineThinking) return;

    const piece = board.board[square];
    const isPlayerPiece = piece && board.isBlackPiece(piece);

    if (selectedSquare === null) {
      if (isPlayerPiece) {
        setSelectedSquare(square);
        setValidMoves(board.getLegalMoves(square));
      }
      return;
    }

    if (square === selectedSquare) {
      setSelectedSquare(null);
      setValidMoves([]);
      return;
    }

    if (validMoves.includes(square)) {
      // Make player move
      const newBoard = board.clone();
      newBoard.makeMove(selectedSquare, square);
      setBoard(newBoard);
      setSelectedSquare(null);
      setValidMoves([]);
      setMoveCount(moveCount + 1);

      // Check if game over
      if (newBoard.isGameOver()) {
        setGameMessage(newBoard.isInCheck(newBoard.whiteToMove) ? '♞ Checkmate! Black wins!' : '♞ Stalemate!');
        return;
      }

      // AI thinks
      setTimeout(() => {
        setEngineThinking(true);
        setTimeout(() => {
          const engineMove = engineRef.current.getBestMove(newBoard, depth);
          if (engineMove) {
            const aiBoard = newBoard.clone();
            aiBoard.makeMove(engineMove.from, engineMove.to);
            setBoard(aiBoard);
            setMoveCount(moveCount + 2);

            if (aiBoard.isGameOver()) {
              setGameMessage(aiBoard.isInCheck(aiBoard.whiteToMove) ? '♞ Checkmate! White wins!' : '♞ Stalemate!');
            } else {
              setGameMessage('♞ Your move');
            }
          }
          setEngineThinking(false);
        }, 100);
      }, 200);
    } else if (isPlayerPiece) {
      setSelectedSquare(square);
      setValidMoves(board.getLegalMoves(square));
    } else {
      setSelectedSquare(null);
      setValidMoves([]);
    }
  }, [board, selectedSquare, validMoves, depth, engineThinking, moveCount]);

  const resetGame = useCallback(() => {
    setBoard(new ChessBoard());
    setSelectedSquare(null);
    setValidMoves([]);
    setGameMessage('♞ Play as Black');
    setMoveCount(0);
  }, []);

  const getPieceName = (char) => {
    const names = { K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
                    k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' };
    return names[char] || '';
  };

  return (
    <div style={{ minHeight: '100vh', padding: '2rem', background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)', fontFamily: 'system-ui, -apple-system' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: '2rem', color: '#fff' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: '700', margin: '0 0 0.5rem 0' }}>Vibe Chess</h1>
          <p style={{ fontSize: '1rem', color: '#aaa', margin: 0 }}>AI engine with personality. Play as Black.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', alignItems: 'start' }}>
          {/* Board */}
          <div>
            <div style={{ background: '#0f3460', padding: '1rem', borderRadius: '8px', boxShadow: '0 8px 32px rgba(0,0,0,0.3)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '0', background: '#1a1a2e', borderRadius: '4px', overflow: 'hidden' }}>
                {board.board.map((piece, square) => {
                  const [row, col] = board.getRowCol(square);
                  const isLight = (row + col) % 2 === 0;
                  const isSelected = square === selectedSquare;
                  const isValidMove = validMoves.includes(square);
                  const isLastMove = board.moveHistory.length > 0 && 
                    (square === board.moveHistory[board.moveHistory.length - 1].to || 
                     square === board.moveHistory[board.moveHistory.length - 1].from);

                  return (
                    <div
                      key={square}
                      onClick={() => handleSquareClick(square)}
                      style={{
                        aspect: '1',
                        background: isSelected ? '#e8b923' : isValidMove ? '#d4a574' : isLastMove ? '#baca44' : isLight ? '#d4d4d4' : '#7d7d7d',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '2rem',
                        cursor: 'pointer',
                        transition: 'background 0.2s',
                        fontWeight: '900',
                        position: 'relative'
                      }}
                      onMouseEnter={(e) => !isSelected && !isValidMove && (e.currentTarget.style.background = isLight ? '#e0e0e0' : '#888')}
                      onMouseLeave={(e) => !isSelected && !isValidMove && (e.currentTarget.style.background = isLight ? '#d4d4d4' : '#7d7d7d')}
                    >
                      {piece && <span style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.3)' }}>{getPieceName(piece)}</span>}
                      {isValidMove && <div style={{ position: 'absolute', width: '8px', height: '8px', background: '#333', borderRadius: '50%' }} />}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Game Status */}
            <div style={{ marginTop: '1.5rem', color: '#fff', fontSize: '1rem' }}>
              <p style={{ margin: '0 0 0.5rem 0' }}>{gameMessage || (engineThinking ? '⏳ Engine thinking...' : '♞ Your move')}</p>
              <p style={{ margin: 0, fontSize: '0.9rem', color: '#aaa' }}>Move: {moveCount}</p>
            </div>

            {/* Buttons */}
            <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem' }}>
              <button
                onClick={resetGame}
                style={{
                  padding: '0.75rem 1.5rem',
                  background: '#e8b923',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '1rem',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#f5c842'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#e8b923'}
              >
                New Game
              </button>
            </div>
          </div>

          {/* Controls */}
          <div style={{ color: '#fff', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Depth Control */}
            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '1.5rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <label style={{ display: 'block', marginBottom: '1rem', fontWeight: '600' }}>
                Search Depth: <span style={{ color: '#e8b923' }}>{depth}</span>
              </label>
              <input
                type="range"
                min="1"
                max="8"
                value={depth}
                onChange={(e) => setDepth(parseInt(e.target.value))}
                disabled={engineThinking}
                style={{ width: '100%', cursor: engineThinking ? 'not-allowed' : 'pointer' }}
              />
              <p style={{ fontSize: '0.85rem', color: '#aaa', margin: '0.75rem 0 0 0' }}>1 = Fast • 8 = Deep (slow)</p>
            </div>

            {/* Personality Controls */}
            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '1.5rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }}>
              <h3 style={{ margin: '0 0 1.5rem 0', fontSize: '1.1rem', fontWeight: '600' }}>⚙️ Play Style</h3>

              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <label style={{ fontWeight: '500' }}>Aggression</label>
                  <span style={{ color: '#e8b923', fontWeight: '600' }}>{aggression}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={aggression}
                  onChange={(e) => setAggression(parseInt(e.target.value))}
                  style={{ width: '100%' }}
                />
                <p style={{ fontSize: '0.8rem', color: '#aaa', margin: '0.5rem 0 0 0' }}>Cautious ← → Risk-Taking</p>
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <label style={{ fontWeight: '500' }}>Positional Play</label>
                  <span style={{ color: '#e8b923', fontWeight: '600' }}>{positional}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={positional}
                  onChange={(e) => setPositional(parseInt(e.target.value))}
                  style={{ width: '100%' }}
                />
                <p style={{ fontSize: '0.8rem', color: '#aaa', margin: '0.5rem 0 0 0' }}>Tactical ← → Strategic</p>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <label style={{ fontWeight: '500' }}>Endgame Technique</label>
                  <span style={{ color: '#e8b923', fontWeight: '600' }}>{endgame}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={endgame}
                  onChange={(e) => setEndgame(parseInt(e.target.value))}
                  style={{ width: '100%' }}
                />
                <p style={{ fontSize: '0.8rem', color: '#aaa', margin: '0.5rem 0 0 0' }}>Weak ← → Strong</p>
              </div>
            </div>

            {/* Info */}
            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '1.5rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)', fontSize: '0.9rem' }}>
              <h4 style={{ margin: '0 0 1rem 0', fontWeight: '600' }}>About This Engine</h4>
              <p style={{ margin: '0 0 0.75rem 0', color: '#ccc' }}>
                <strong>Vibe Chess</strong> uses alpha-beta minimax with iterative deepening. Your play style directly affects AI behavior via dynamic evaluation weights.
              </p>
              <p style={{ margin: 0, color: '#999', fontSize: '0.85rem' }}>
                Open source • MIT License • Built with React
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
