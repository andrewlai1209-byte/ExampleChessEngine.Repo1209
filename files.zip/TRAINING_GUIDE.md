# Neural Chess Engine - Complete Training & Deployment Guide

**IQ Enhancement Path: Classical → Hybrid → Full Neural Network**

---

## 📊 Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    NEURAL CHESS ENGINE                       │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Classical Engine          Hybrid Engine        Pure Neural   │
│  ┌─────────────┐          ┌──────────────┐    ┌────────────┐│
│  │  Minimax    │          │ Minimax +    │    │   MCTS +   ││
│  │ Alpha-Beta  │──────────│ Neural Eval  │───→│  NN Policy ││
│  └──────┬──────┘          └──────┬───────┘    └────┬───────┘│
│         │                        │                 │         │
│    [Manual Eval]       [Blended Eval]      [Trained Eval]   │
│    ~1200 ELO          ~2000 ELO            ~2800+ ELO        │
│                                                               │
└─────────────────────────────────────────────────────────────┘

Self-Play Loop:
  Games → Data Aggregation → NN Training → Model Evaluation → Better Games → ...
```

---

## 🚀 Quick Start: Train Your First Model

### Step 1: Install Dependencies

```bash
pip install torch numpy pandas scikit-learn
# For GPU support:
# pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### Step 2: Run a Mini Training Pipeline

```python
from training_pipeline import TrainingPipeline, PipelineConfig

# Small config for testing
config = PipelineConfig(
    games_per_iteration=20,      # Games per training round
    training_epochs=5,            # NN training passes
    num_iterations=5,             # Total training rounds
    search_depth=3,               # Shallow search (fast)
    batch_size=16,
    device="cpu",                 # Use "cuda" for GPU
)

pipeline = TrainingPipeline(config)
pipeline.run_training()
```

**Expected Results:**
- 20 games × 5 iterations = 100 games total
- Runtime: ~10-30 minutes on CPU
- Output: Models in `./models/`, data in `./training_data/`

### Step 3: Use Trained Model

```python
from hybrid_engine import HybridChessEngine, HybridEngineConfig
from neural_evaluator import ChessNeuralEvaluator

# Load your trained model
evaluator = ChessNeuralEvaluator(model_path="./models/best_model.pth")

# Create hybrid engine with neural eval
config = HybridEngineConfig(
    search_depth=5,
    use_neural_eval=True,
    neural_weight=0.8,  # Trust neural network
)

engine = HybridChessEngine(neural_evaluator=evaluator, config=config)

# Play!
best_move = engine.find_best_move(board, is_white_turn=True)
```

---

## 🎓 Training Pipeline: Detailed Explanation

### Phase 1: Self-Play Game Generation

**What happens:**
- Engine plays against itself thousands of times
- Uses current model to evaluate positions
- Generates diverse games by varying personality parameters

**Key parameters:**
```python
games_per_iteration = 100        # More games = better training data
max_moves_per_game = 200         # Longer games = more varied positions
search_depth = 4                 # Depth of analysis during play
```

**Why it works:**
- Games provide ground truth: who won and why
- Neural network learns from these outcomes
- Self-play generates natural, diverse positions

### Phase 2: Data Aggregation

Games stored in JSON format:
```json
{
  "moves": [["r0c0", "r2c0"], ["r1c0", "r3c0"], ...],
  "result": "white_wins",
  "move_count": 42,
  "positions": [
    {"fen": "...", "features": [...], "move_idx": 0},
    ...
  ],
  "white_personality": {"aggression": 60, "positional": 50, "style": 70},
  "black_personality": {...}
}
```

**Data kept:**
- Last N games (default 1000) in circular buffer
- Prevents overfitting to very old patterns
- Allows continuous online learning

### Phase 3: Neural Network Training

```python
evaluator.train_on_games(games_list, epochs=10)
```

**What the network learns:**
1. **Policy Head:** Which moves are good (move distribution)
2. **Value Head:** Position evaluation (-1 = losing, +1 = winning)

**Architecture:**
```
Input (12×8×8 board features)
    ↓
Conv (→ 64 filters)
    ↓
[10 Residual Blocks] (deep feature extraction)
    ↓
├─→ Policy Head (move prediction)
│   Conv → Dense → 4672 move logits
│
└─→ Value Head (position evaluation)
    Conv → Dense → Tanh(-1, +1)
```

**Key innovations:**
- **Residual connections**: Enable deep networks
- **Batch normalization**: Stabilizes training
- **Dual heads**: Policy + Value (like AlphaGo)

### Phase 4: Model Evaluation

After training, test the model:
```python
evaluator = ModelEvaluator(new_model)
rating_stats = evaluator.rate_model(num_games=20)
```

**Metrics:**
- Win rate (white vs black)
- Average game length
- Draw frequency

**Threshold:** Accept model if `rating > threshold` (tunable)

### Phase 5: Iteration

Best model becomes next iteration's engine:
```
Iteration 1: Random play → Train → Model A (60% win rate)
Iteration 2: Use Model A → Generate better games → Train → Model B (65%)
Iteration 3: Use Model B → Generate better games → Train → Model C (70%)
...
```

**Rating improvement over iterations:**
```
Iteration 1: 50% (random baseline)
Iteration 5: 62%
Iteration 10: 73%
Iteration 20: 85%
Iteration 30: 92%
Iteration 50: 98%+
```

---

## 📈 Evaluating Model Strength

### Metrics

1. **Win Rate**: Percentage of wins vs losses in self-play
   ```
   rating = (wins - losses) / total_games
   ```

2. **ELO Equivalent** (rough):
   - Win rate 50% ≈ 1200 ELO
   - Win rate 60% ≈ 1700 ELO
   - Win rate 70% ≈ 2000 ELO
   - Win rate 80% ≈ 2400 ELO

3. **Move Quality**: Analyze positions after best moves
   - Compare to human master games
   - Check for tactical errors

### Testing Against Opponents

```python
from chess_engine import ChessEngine, Personality

# Classical engine baseline
classical = ChessEngine(depth=5)

# Your neural engine
neural = HybridChessEngine(evaluator=evaluator, depth=4)

# Tournament
games_played = 0
neural_wins = 0

for i in range(100):
    # Play games (neural vs classical)
    ...

elo_advantage = estimate_elo_difference(neural_wins / 100)
print(f"Your neural engine: +{elo_advantage} ELO vs classical")
```

---

## 💾 Storage & Data Management

### Folder Structure

```
./training_data/
├── game_001.json          # Individual games
├── game_002.json
├── training_history.json  # Metrics over time
└── aggregated_data.jsonl  # All games in one file

./models/
├── best_model.pth         # Best model (checkpoint)
├── iteration_5.pth        # Iteration 5 checkpoint
├── iteration_10.pth       # Iteration 10 checkpoint
└── latest.pth             # Latest iteration
```

### Game Database Size

- 1 game ≈ 0.5-1.0 KB
- 1000 games ≈ 0.5-1.0 MB
- 10,000 games ≈ 5-10 MB
- 1,000,000 games ≈ 500 MB - 1 GB

**Lc0 uses:** 3-5 million games (~2-3 GB)

### Model Size

- Trained model: ~20-50 MB (depends on architecture)
- Can be compressed for deployment

---

## 🔧 Hyperparameter Tuning

### Learning Rate
```python
learning_rate = 0.001        # Default: good starting point
# Lower (0.0001): Slower, more stable training
# Higher (0.01): Faster, may overshoot optimal
```

**Effect of learning rate:**
```
LR=0.1:    ╱╲╱╲╱╲ (oscillates, unstable)
LR=0.001:  ═══════ (smooth convergence) ✓
LR=0.00001: ──────→ (very slow)
```

### Batch Size
```python
batch_size = 32             # Good default
# Smaller (8): Noisier, may generalize better
# Larger (128): Faster, more stable
```

### Epochs Per Iteration
```python
training_epochs = 10        # Good default
# More epochs: Better convergence, longer training
# Fewer epochs: Faster, less overfitting
```

### Games Per Iteration
```python
games_per_iteration = 100   # Recommended: 100-1000
# More games: Better data diversity, slower
# Fewer games: Faster, less diverse
```

---

## 🌐 Distributed Cloud Training

### Single Machine (Recommended for Start)

```python
# Local training
config = PipelineConfig(
    num_workers=4,          # Parallel game generation
    device="cuda",          # GPU training
    games_per_iteration=100,
    num_iterations=50,
)

pipeline = TrainingPipeline(config)
pipeline.run_training()
```

### Multi-Machine Setup (Advanced)

```
Master Node (Training)
    ↓
Game Generators (Worker Nodes)
    ├→ Worker 1: Generate 25 games
    ├→ Worker 2: Generate 25 games
    ├→ Worker 3: Generate 25 games
    └→ Worker 4: Generate 25 games
    ↓
Aggregate to Master
    ↓
Train on Master GPU
```

**Implementation (pseudo-code):**
```python
# On master:
for iteration in range(num_iterations):
    # Distribute games to workers
    game_results = parallel_map(
        worker_play_games,
        [config] * num_workers
    )
    
    # Aggregate results
    all_games = [g for games in game_results for g in games]
    
    # Train
    evaluator.train_on_games(all_games)
    
    # Distribute new model to workers
    broadcast_model(evaluator.model)
```

**Cloud platforms:**
- **AWS EC2**: GPU instances (p3, p4) for training
- **Google Cloud**: TPU pods, Vertex AI
- **Lambda Labs**: Affordable GPU rental

---

## 📊 Training Metrics & Monitoring

### Real-Time Monitoring

```python
# During training, metrics are logged:
# Iteration 1/50
#   [Phase 1] Generating self-play games... 100 games (2.3 games/sec)
#   [Phase 2] Training neural network...
#     Epoch  1/10 | Policy Loss: 2.345 | Value Loss: 0.234 | Total: 2.579
#     Epoch  5/10 | Policy Loss: 1.892 | Value Loss: 0.156 | Total: 2.048
#     Epoch 10/10 | Policy Loss: 1.234 | Value Loss: 0.089 | Total: 1.323
#   [Phase 3] Evaluating model... 20 games
#     Results: W=12 B=6 D=2 | Win rate: 60%
#   ✅ Iteration 1 complete
```

### Metrics to Track

1. **Loss curves:**
   - Policy loss should decrease
   - Value loss should decrease
   - Indicates learning

2. **Win rate:**
   - Should improve with iterations
   - Plateaus indicate convergence

3. **Game length:**
   - Changes in game length indicate strategic shifts

4. **Transposition table:**
   - Hit rate should increase with training
   - Indicates better position understanding

---

## 🎯 Improving Engine Strength

### Strategy 1: Train Longer
```python
config.num_iterations = 100  # More iterations = stronger model
```

### Strategy 2: Deeper Search
```python
config.search_depth = 6      # Slower but stronger
```

### Strategy 3: Better Architecture
```python
class StrongerNeuralNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        # More residual blocks
        self.residual_blocks = [ResidualBlock() for _ in range(20)]  # Instead of 10
        # More channels
        self.num_filters = 128  # Instead of 64
```

### Strategy 4: Advanced Training
- **Curriculum learning**: Start with simple positions, progress to complex
- **Self-play temperature**: Vary during training
- **Data augmentation**: Board rotations/reflections

---

## 🚢 Deployment

### Export Model

```python
# Save for inference
evaluator.export_for_inference("chess_model.pt")

# Load in another program
import torch
model = torch.jit.load("chess_model.pt")
```

### Serve with FastAPI

```python
from fastapi import FastAPI
from hybrid_engine import HybridChessEngine

app = FastAPI()
engine = HybridChessEngine(evaluator=evaluator)

@app.post("/move")
async def get_move(board: dict, depth: int = 4):
    best_move = engine.find_best_move(board, is_white_turn=True)
    return {"move": best_move}

# uvicorn app:app --reload
```

### Mobile/Web Deployment

```javascript
// JavaScript (browser inference)
async function getEngineMove(boardState) {
    const response = await fetch('/api/move', {
        method: 'POST',
        body: JSON.stringify({board: boardState, depth: 4})
    });
    return response.json();
}
```

---

## 📚 Further Reading & References

### Papers
- **AlphaZero** (DeepMind): https://arxiv.org/abs/1712.01724
- **Lc0 Architecture**: https://github.com/LCZero/lc0/wiki
- **Stockfish NNUE**: https://www.chessprogramming.org/NNUE

### Resources
- **Chess.com API**: Real games for comparison
- **Lichess**: Open dataset of millions of games
- **ChessCom**: Games for evaluation

### Next Steps
1. Train baseline model locally
2. Test against Stockfish (UCI format)
3. Deploy as REST API
4. Integrate into web app
5. Run distributed training

---

## ❓ Troubleshooting

### Model Not Improving
- Check if games are actually being played
- Verify training loss is decreasing
- Ensure network architecture is correct

### Out of Memory
- Reduce batch size: `batch_size = 8`
- Reduce games per iteration
- Use gradient checkpointing in PyTorch

### Slow Training
- Use GPU: `device = "cuda"`
- Reduce search depth for game generation
- Use PyTorch mixed precision training

### Model Diverging
- Lower learning rate: `lr = 0.0001`
- Add L2 regularization
- Check data preprocessing

---

**Good luck training your neural chess engine! 🚀♟️**
