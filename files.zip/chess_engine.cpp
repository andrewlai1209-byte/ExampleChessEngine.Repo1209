// Neural Chess Engine - C++ Core
// High-performance chess engine with personality system
// MIT License - Open Source

#include <iostream>
#include <vector>
#include <array>
#include <string>
#include <cmath>
#include <algorithm>
#include <chrono>
#include <unordered_map>

constexpr int BOARD_SIZE = 8;
constexpr int MAX_DEPTH = 10;
constexpr float INFINITY_VAL = 1e9;

enum class PieceType {
    NONE = 0,
    PAWN = 1,
    KNIGHT = 2,
    BISHOP = 3,
    ROOK = 4,
    QUEEN = 5,
    KING = 6
};

struct Piece {
    PieceType type;
    bool is_white;
    
    Piece() : type(PieceType::NONE), is_white(true) {}
    Piece(PieceType t, bool w) : type(t), is_white(w) {}
    
    bool operator==(const Piece& other) const {
        return type == other.type && is_white == other.is_white;
    }
    
    bool operator!=(const Piece& other) const {
        return !(*this == other);
    }
};

struct Personality {
    float aggression;      // 0-100: defensive to reckless
    float positional;      // 0-100: material focus to position focus
    float style;           // 0-100: solid/safe to attacking/creative
    
    Personality(float agg = 50.f, float pos = 50.f, float stl = 50.f)
        : aggression(agg), positional(pos), style(stl) {}
};

struct Move {
    int from_row, from_col;
    int to_row, to_col;
    
    Move() : from_row(0), from_col(0), to_row(0), to_col(0) {}
    Move(int fr, int fc, int tr, int tc)
        : from_row(fr), from_col(fc), to_row(tr), to_col(tc) {}
    
    bool operator==(const Move& other) const {
        return from_row == other.from_row && from_col == other.from_col &&
               to_row == other.to_row && to_col == other.to_col;
    }
};

class ChessBoard {
public:
    static constexpr int PIECE_VALUES[] = {0, 1, 3, 3, 5, 9, 0}; // NONE, P, N, B, R, Q, K
    
    std::array<std::array<Piece, BOARD_SIZE>, BOARD_SIZE> board;
    std::vector<Move> move_history;
    
    ChessBoard() {
        // Initialize starting position
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                board[i][j] = Piece();
            }
        }
        
        // Place white pieces
        board[7][0] = Piece(PieceType::ROOK, true);
        board[7][1] = Piece(PieceType::KNIGHT, true);
        board[7][2] = Piece(PieceType::BISHOP, true);
        board[7][3] = Piece(PieceType::QUEEN, true);
        board[7][4] = Piece(PieceType::KING, true);
        board[7][5] = Piece(PieceType::BISHOP, true);
        board[7][6] = Piece(PieceType::KNIGHT, true);
        board[7][7] = Piece(PieceType::ROOK, true);
        
        for (int i = 0; i < BOARD_SIZE; i++) {
            board[6][i] = Piece(PieceType::PAWN, true);
        }
        
        // Place black pieces
        board[0][0] = Piece(PieceType::ROOK, false);
        board[0][1] = Piece(PieceType::KNIGHT, false);
        board[0][2] = Piece(PieceType::BISHOP, false);
        board[0][3] = Piece(PieceType::QUEEN, false);
        board[0][4] = Piece(PieceType::KING, false);
        board[0][5] = Piece(PieceType::BISHOP, false);
        board[0][6] = Piece(PieceType::KNIGHT, false);
        board[0][7] = Piece(PieceType::ROOK, false);
        
        for (int i = 0; i < BOARD_SIZE; i++) {
            board[1][i] = Piece(PieceType::PAWN, false);
        }
    }
    
    ChessBoard(const ChessBoard& other) = default;
    
    bool in_bounds(int row, int col) const {
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }
    
    Piece get_piece(int row, int col) const {
        if (in_bounds(row, col)) {
            return board[row][col];
        }
        return Piece();
    }
    
    void set_piece(int row, int col, const Piece& piece) {
        if (in_bounds(row, col)) {
            board[row][col] = piece;
        }
    }
    
    std::vector<Move> get_legal_moves(int row, int col) const {
        std::vector<Move> moves;
        Piece piece = get_piece(row, col);
        
        if (piece.type == PieceType::NONE) return moves;
        
        switch (piece.type) {
            case PieceType::PAWN:
                add_pawn_moves(row, col, piece.is_white, moves);
                break;
            case PieceType::KNIGHT:
                add_knight_moves(row, col, piece.is_white, moves);
                break;
            case PieceType::BISHOP:
                add_sliding_moves(row, col, piece.is_white, {{-1,-1},{-1,1},{1,-1},{1,1}}, moves);
                break;
            case PieceType::ROOK:
                add_sliding_moves(row, col, piece.is_white, {{-1,0},{1,0},{0,-1},{0,1}}, moves);
                break;
            case PieceType::QUEEN:
                add_sliding_moves(row, col, piece.is_white, 
                    {{-1,0},{1,0},{0,-1},{0,1},{-1,-1},{-1,1},{1,-1},{1,1}}, moves);
                break;
            case PieceType::KING:
                add_king_moves(row, col, piece.is_white, moves);
                break;
            default:
                break;
        }
        
        return moves;
    }
    
    std::vector<Move> get_all_moves(bool is_white_turn) const {
        std::vector<Move> all_moves;
        for (int r = 0; r < BOARD_SIZE; r++) {
            for (int c = 0; c < BOARD_SIZE; c++) {
                Piece piece = get_piece(r, c);
                if (piece.type != PieceType::NONE && piece.is_white == is_white_turn) {
                    auto moves = get_legal_moves(r, c);
                    all_moves.insert(all_moves.end(), moves.begin(), moves.end());
                }
            }
        }
        return all_moves;
    }
    
    void make_move(const Move& move) {
        Piece piece = get_piece(move.from_row, move.from_col);
        set_piece(move.to_row, move.to_col, piece);
        set_piece(move.from_row, move.from_col, Piece());
        move_history.push_back(move);
    }
    
    void undo_move() {
        if (move_history.empty()) return;
        Move last_move = move_history.back();
        move_history.pop_back();
        
        Piece piece = get_piece(last_move.to_row, last_move.to_col);
        set_piece(last_move.from_row, last_move.from_col, piece);
        set_piece(last_move.to_row, last_move.to_col, Piece());
    }
    
    bool is_in_check(bool is_white) const {
        // Find king
        int king_row = -1, king_col = -1;
        for (int r = 0; r < BOARD_SIZE; r++) {
            for (int c = 0; c < BOARD_SIZE; c++) {
                Piece piece = get_piece(r, c);
                if (piece.type == PieceType::KING && piece.is_white == is_white) {
                    king_row = r;
                    king_col = c;
                    break;
                }
            }
            if (king_row != -1) break;
        }
        
        if (king_row == -1) return false;
        
        // Check if any enemy piece attacks king
        for (int r = 0; r < BOARD_SIZE; r++) {
            for (int c = 0; c < BOARD_SIZE; c++) {
                Piece piece = get_piece(r, c);
                if (piece.type != PieceType::NONE && piece.is_white != is_white) {
                    auto moves = get_legal_moves(r, c);
                    for (const Move& move : moves) {
                        if (move.to_row == king_row && move.to_col == king_col) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    bool has_legal_moves(bool is_white_turn) const {
        return !get_all_moves(is_white_turn).empty();
    }

private:
    void add_pawn_moves(int row, int col, bool is_white, std::vector<Move>& moves) const {
        int direction = is_white ? -1 : 1;
        int start_row = is_white ? 6 : 1;
        
        // Forward move
        int forward_row = row + direction;
        if (in_bounds(forward_row, col) && get_piece(forward_row, col).type == PieceType::NONE) {
            moves.push_back(Move(row, col, forward_row, col));
            
            // Double move
            if (row == start_row) {
                int forward2 = row + 2 * direction;
                if (get_piece(forward2, col).type == PieceType::NONE) {
                    moves.push_back(Move(row, col, forward2, col));
                }
            }
        }
        
        // Captures
        for (int dc : {-1, 1}) {
            int capture_row = row + direction;
            int capture_col = col + dc;
            if (in_bounds(capture_row, capture_col)) {
                Piece target = get_piece(capture_row, capture_col);
                if (target.type != PieceType::NONE && target.is_white != is_white) {
                    moves.push_back(Move(row, col, capture_row, capture_col));
                }
            }
        }
    }
    
    void add_knight_moves(int row, int col, bool is_white, std::vector<Move>& moves) const {
        std::array<std::pair<int, int>, 8> directions = {{
            {-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}
        }};
        
        for (auto [dr, dc] : directions) {
            int new_row = row + dr;
            int new_col = col + dc;
            if (in_bounds(new_row, new_col)) {
                Piece target = get_piece(new_row, new_col);
                if (target.type == PieceType::NONE || target.is_white != is_white) {
                    moves.push_back(Move(row, col, new_row, new_col));
                }
            }
        }
    }
    
    void add_king_moves(int row, int col, bool is_white, std::vector<Move>& moves) const {
        std::array<std::pair<int, int>, 8> directions = {{
            {-1,0},{1,0},{0,-1},{0,1},{-1,-1},{-1,1},{1,-1},{1,1}
        }};
        
        for (auto [dr, dc] : directions) {
            int new_row = row + dr;
            int new_col = col + dc;
            if (in_bounds(new_row, new_col)) {
                Piece target = get_piece(new_row, new_col);
                if (target.type == PieceType::NONE || target.is_white != is_white) {
                    moves.push_back(Move(row, col, new_row, new_col));
                }
            }
        }
    }
    
    void add_sliding_moves(int row, int col, bool is_white,
                          const std::vector<std::pair<int, int>>& directions,
                          std::vector<Move>& moves) const {
        for (auto [dr, dc] : directions) {
            int new_row = row + dr;
            int new_col = col + dc;
            while (in_bounds(new_row, new_col)) {
                Piece target = get_piece(new_row, new_col);
                if (target.type == PieceType::NONE) {
                    moves.push_back(Move(row, col, new_row, new_col));
                } else {
                    if (target.is_white != is_white) {
                        moves.push_back(Move(row, col, new_row, new_col));
                    }
                    break;
                }
                new_row += dr;
                new_col += dc;
            }
        }
    }
};

class ChessEngine {
public:
    Personality personality;
    int depth;
    long long nodes_evaluated;
    
    ChessEngine(const Personality& pers = Personality(), int d = 4)
        : personality(pers), depth(d), nodes_evaluated(0) {}
    
    float evaluate(const ChessBoard& board) const {
        float score = 0.0f;
        
        // Material count
        for (int r = 0; r < BOARD_SIZE; r++) {
            for (int c = 0; c < BOARD_SIZE; c++) {
                Piece piece = board.get_piece(r, c);
                if (piece.type != PieceType::NONE) {
                    int value = ChessBoard::PIECE_VALUES[static_cast<int>(piece.type)];
                    if (piece.is_white) {
                        score += value;
                    } else {
                        score -= value;
                    }
                }
            }
        }
        
        // Positional bonuses
        for (int r = 0; r < BOARD_SIZE; r++) {
            for (int c = 0; c < BOARD_SIZE; c++) {
                Piece piece = board.get_piece(r, c);
                if (piece.type == PieceType::NONE) continue;
                
                // Central control
                float dist_to_center = std::abs(r - 3.5f) + std::abs(c - 3.5f);
                float central_bonus = (8.0f - dist_to_center) * (personality.positional / 100.0f) * 0.2f;
                if (piece.is_white) {
                    score += central_bonus;
                } else {
                    score -= central_bonus;
                }
                
                // Aggression bonus
                if (personality.aggression > 50.0f) {
                    int num_attacks = board.get_legal_moves(r, c).size();
                    float agg_bonus = num_attacks * ((personality.aggression - 50.0f) / 50.0f) * 0.1f;
                    if (piece.is_white) {
                        score += agg_bonus;
                    } else {
                        score -= agg_bonus;
                    }
                }
            }
        }
        
        return score;
    }
    
    Move find_best_move(ChessBoard& board, bool is_white_turn) {
        nodes_evaluated = 0;
        auto moves = board.get_all_moves(is_white_turn);
        
        if (moves.empty()) {
            return Move();
        }
        
        Move best_move = moves[0];
        float best_eval = is_white_turn ? -INFINITY_VAL : INFINITY_VAL;
        
        for (const Move& move : moves) {
            board.make_move(move);
            float eval = minimax(board, depth - 1, -INFINITY_VAL, INFINITY_VAL, !is_white_turn);
            board.undo_move();
            
            if (is_white_turn) {
                if (eval > best_eval) {
                    best_eval = eval;
                    best_move = move;
                }
            } else {
                if (eval < best_eval) {
                    best_eval = eval;
                    best_move = move;
                }
            }
        }
        
        return best_move;
    }

private:
    float minimax(ChessBoard& board, int current_depth, float alpha, float beta, bool is_maximizing) {
        nodes_evaluated++;
        
        if (current_depth == 0) {
            return evaluate(board);
        }
        
        auto moves = board.get_all_moves(is_maximizing);
        if (moves.empty()) {
            if (board.is_in_check(is_maximizing)) {
                return is_maximizing ? -10000.0f : 10000.0f;
            }
            return 0.0f;
        }
        
        if (is_maximizing) {
            float max_eval = -INFINITY_VAL;
            for (const Move& move : moves) {
                board.make_move(move);
                float eval = minimax(board, current_depth - 1, alpha, beta, false);
                board.undo_move();
                
                max_eval = std::max(max_eval, eval);
                alpha = std::max(alpha, eval);
                if (beta <= alpha) break;
            }
            return max_eval;
        } else {
            float min_eval = INFINITY_VAL;
            for (const Move& move : moves) {
                board.make_move(move);
                float eval = minimax(board, current_depth - 1, alpha, beta, true);
                board.undo_move();
                
                min_eval = std::min(min_eval, eval);
                beta = std::min(beta, eval);
                if (beta <= alpha) break;
            }
            return min_eval;
        }
    }
};

// Example usage
int main() {
    std::cout << "♟️ Neural Chess Engine - C++ Core\n";
    std::cout << "====================================\n\n";
    
    Personality personality(75.0f, 60.0f, 70.0f);
    ChessEngine engine(personality, 4);
    
    ChessBoard board;
    bool is_white_turn = true;
    int move_count = 0;
    
    std::cout << "Engine Personality:\n";
    std::cout << "  Aggression: " << personality.aggression << "\n";
    std::cout << "  Positional: " << personality.positional << "\n";
    std::cout << "  Style: " << personality.style << "\n\n";
    
    while (board.has_legal_moves(is_white_turn) && move_count < 100) {
        std::string side = is_white_turn ? "White" : "Black";
        std::cout << side << "'s turn...\n";
        
        auto start = std::chrono::high_resolution_clock::now();
        Move best_move = engine.find_best_move(board, is_white_turn);
        auto end = std::chrono::high_resolution_clock::now();
        
        if (best_move.from_row == 0 && best_move.from_col == 0 && 
            best_move.to_row == 0 && best_move.to_col == 0) {
            std::cout << "No legal moves available\n";
            break;
        }
        
        board.make_move(best_move);
        
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        std::cout << "Move: [" << best_move.from_row << "," << best_move.from_col << "] -> "
                  << "[" << best_move.to_row << "," << best_move.to_col << "]\n";
        std::cout << "Nodes evaluated: " << engine.nodes_evaluated 
                  << ", Time: " << duration.count() << "ms\n\n";
        
        is_white_turn = !is_white_turn;
        move_count++;
    }
    
    std::cout << "Game ended after " << move_count << " moves\n";
    
    return 0;
}
